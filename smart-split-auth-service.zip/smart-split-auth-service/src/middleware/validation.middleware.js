const { validationResult, body } = require('express-validator');

/**
 * Middleware для проверки результатов валидации
 */
exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

/**
 * Валидация запроса регистрации
 */
exports.registerValidation = [
  body('firstName')
    .trim()
    .notEmpty().withMessage('Имя обязательно')
    .isLength({ min: 2, max: 50 }).withMessage('Имя должно быть от 2 до 50 символов'),
  
  body('lastName')
    .trim()
    .notEmpty().withMessage('Фамилия обязательна')
    .isLength({ min: 2, max: 50 }).withMessage('Фамилия должна быть от 2 до 50 символов'),
  
  body('email')
    .trim()
    .notEmpty().withMessage('Email обязателен')
    .isEmail().withMessage('Введите корректный email'),
  
  body('password')
    .trim()
    .notEmpty().withMessage('Пароль обязателен')
    .isLength({ min: 6 }).withMessage('Пароль должен быть не менее 6 символов')
];

/**
 * Валидация запроса авторизации
 */
exports.loginValidation = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email обязателен')
    .isEmail().withMessage('Введите корректный email'),
  
  body('password')
    .trim()
    .notEmpty().withMessage('Пароль обязателен')
];

/**
 * Валидация запроса обновления профиля
 */
exports.updateProfileValidation = [
  body('firstName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 }).withMessage('Имя должно быть от 2 до 50 символов'),
  
  body('lastName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 }).withMessage('Фамилия должна быть от 2 до 50 символов'),
  
  body('password')
    .optional()
    .trim()
    .isLength({ min: 6 }).withMessage('Пароль должен быть не менее 6 символов')
]; 