const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const { User } = require('../models');

/**
 * Middleware для проверки JWT токена
 */
exports.authenticate = async (req, res, next) => {
  try {
    // Получение токена из заголовка Authorization
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Токен авторизации отсутствует' });
    }
    
    const token = authHeader.split(' ')[1];
    
    // Верификация токена
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'smart_split_secret');
    
    // Установка данных пользователя в объект запроса
    req.user = decoded;
    
    // Проверка существования пользователя
    const user = await User.findByPk(decoded.id);
    if (!user) {
      return res.status(401).json({ message: 'Пользователь не найден' });
    }
    
    // Проверка активности аккаунта
    if (!user.isActive) {
      return res.status(403).json({ message: 'Аккаунт заблокирован' });
    }
    
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Токен авторизации истек' });
    }
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Недействительный токен авторизации' });
    }
    
    logger.error(`Ошибка аутентификации: ${error.message}`);
    next(error);
  }
};

/**
 * Middleware для проверки роли пользователя
 */
exports.authorize = (roles = []) => {
  if (typeof roles === 'string') {
    roles = [roles];
  }
  
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Доступ запрещен' });
    }
    
    next();
  };
}; 