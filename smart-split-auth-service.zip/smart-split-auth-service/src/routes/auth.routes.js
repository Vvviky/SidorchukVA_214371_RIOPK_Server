const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { 
  registerValidation, 
  loginValidation, 
  updateProfileValidation, 
  validate 
} = require('../middleware/validation.middleware');

/**
 * @route POST /api/auth/register
 * @desc Регистрация нового пользователя
 * @access Public
 */
router.post('/register', registerValidation, validate, authController.register);

/**
 * @route POST /api/auth/login
 * @desc Авторизация пользователя
 * @access Public
 */
router.post('/login', loginValidation, validate, authController.login);

/**
 * @route GET /api/auth/check
 * @desc Проверка авторизации пользователя
 * @access Private
 */
router.get('/check', authenticate, authController.check);

/**
 * @route GET /api/auth/me
 * @desc Получение данных текущего пользователя
 * @access Private
 */
router.get('/me', authenticate, authController.getCurrentUser);

/**
 * @route PUT /api/auth/profile
 * @desc Обновление данных пользователя
 * @access Private
 */
router.put('/profile', authenticate, updateProfileValidation, validate, authController.updateProfile);

/**
 * @route GET /api/auth/users
 * @desc Получение списка всех пользователей
 * @access Private (Admin only)
 */
router.get('/users', authenticate, authController.getAllUsers);

/**
 * @route PATCH /api/auth/users/:userId/role
 * @desc Обновление роли пользователя
 * @access Private (Admin only)
 */
router.patch('/users/:userId/role', authenticate, authController.updateUserRole);

/**
 * @route PATCH /api/auth/users/:userId/status
 * @desc Обновление статуса активности пользователя
 * @access Private (Admin only)
 */
router.patch('/users/:userId/status', authenticate, authController.updateUserStatus);

module.exports = router; 