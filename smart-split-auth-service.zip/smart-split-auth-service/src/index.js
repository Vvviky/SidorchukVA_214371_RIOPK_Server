const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { sequelize } = require('./models');
const authRoutes = require('./routes/auth.routes');
const logger = require('./utils/logger');

 
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

 
app.use(cors());
app.use(express.json());

 
app.use('/api/auth', authRoutes);
 
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', service: 'auth-service' });
});
 
app.use((err, req, res, next) => {
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`);
  
  res.status(err.status || 500).json({
    message: err.message || 'Внутренняя ошибка сервера',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});
 
const startServer = async () => {
  try {
    await sequelize.authenticate();
    logger.info('Успешное подключение к базе данных');

    await sequelize.sync({ alter: process.env.NODE_ENV === 'development' });
    logger.info('Синхронизация моделей с базой данных завершена');

    app.listen(PORT, () => {
      logger.info(`Сервер аутентификации запущен на порту ${PORT}`);
    });
  } catch (error) {
    logger.error('Ошибка при запуске сервера:', error);
    process.exit(1);
  }
};

startServer(); 