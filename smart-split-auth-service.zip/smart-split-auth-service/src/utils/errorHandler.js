const errorHandler = (err, req, res, next) => {
  console.error(err.stack);

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: {
        code: 400,
        message: 'Ошибка валидации',
        details: err.errors
      }
    });
  }

  if (err.name === 'SequelizeUniqueConstraintError') {
    return res.status(409).json({
      error: {
        code: 409,
        message: 'Email уже используется',
        details: {
          email: 'Этот email уже зарегистрирован'
        }
      }
    });
  }

  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({
      error: {
        code: 401,
        message: 'Неверный токен',
        details: 'Требуется повторная авторизация'
      }
    });
  }

  if (err.name === 'TokenExpiredError') {
    return res.status(401).json({
      error: {
        code: 401,
        message: 'Токен истек',
        details: 'Требуется повторная авторизация'
      }
    });
  }

  if (err.name === 'ApiError') {
    return res.status(err.status).json({
      error: {
        code: err.status,
        message: err.message,
        details: err.details || {}
      }
    });
  }

  res.status(500).json({
    error: {
      code: 500,
      message: 'Внутренняя ошибка сервера',
      details: process.env.NODE_ENV === 'development' ? err.message : 'Произошла ошибка. Пожалуйста, попробуйте позже.'
    }
  });
};

module.exports = errorHandler; 