const jwt = require('jsonwebtoken');
const { User } = require('../models');
const logger = require('../utils/logger');

// Генерация JWT токена
const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET || 'smart_split_secret',
    { expiresIn: '24h' }
  );
};

/**
 * Регистрация нового пользователя
 */
exports.register = async (req, res, next) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    
    if (!firstName || !lastName || !email || !password) {
      return res.status(400).json({ message: 'Все поля обязательны для заполнения' });
    }
    
    // Проверка существования пользователя
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
    }
    
    // Создание нового пользователя
    const user = await User.create({ 
      firstName, 
      lastName, 
      email, 
      password,
      role: 'user',
      isActive: true
    });
    
    // Генерация токена
    const token = generateToken(user);
    
    logger.info(`Зарегистрирован новый пользователь: ${email}`);
    
    res.status(201).json({
      message: 'Пользователь успешно зарегистрирован',
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      },
      token
    });
  } catch (error) {
    logger.error(`Ошибка при регистрации: ${error.message}`);
    next(error);
  }
};

/**
 * Авторизация пользователя
 */
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: 'Email и пароль обязательны' });
    }
    
    // Поиск пользователя
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({ message: 'Неверный email или пароль' });
    }
    
    // Проверка статуса активности
    if (!user.isActive) {
      return res.status(403).json({ message: 'Аккаунт заблокирован' });
    }
    
    // Проверка пароля
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Неверный email или пароль' });
    }
    
    // Обновление времени последнего входа
    user.lastLogin = new Date();
    await user.save();
    
    // Генерация токена
    const token = generateToken(user);
    
    logger.info(`Пользователь авторизован: ${email}`);
    
    res.json({
      message: 'Авторизация успешна',
      user: user.toJSON(),
      token
    });
  } catch (error) {
    logger.error(`Ошибка при авторизации: ${error.message}`);
    next(error);
  }
};

/**
 * Проверка авторизации пользователя
 */
exports.check = async (req, res, next) => {
  try {
    // Пользователь был аутентифицирован в middleware
    const user = await User.findByPk(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    res.json({
      user: user.toJSON()
    });
  } catch (error) {
    logger.error(`Ошибка при проверке авторизации: ${error.message}`);
    next(error);
  }
};

/**
 * Получение информации о текущем пользователе
 */
exports.getCurrentUser = async (req, res, next) => {
  try {
    const userId = req.user.id;
    
    if (!userId) {
      logger.error('Не удалось определить ID пользователя из токена');
      return res.status(401).json({ 
        message: 'Не удалось идентифицировать пользователя',
        details: 'Данные пользователя отсутствуют в токене'
      });
    }
    
    logger.info(`Получение информации о пользователе: ${userId}`);
    
    const user = await User.findByPk(userId);
    
    if (!user) {
      logger.error(`Пользователь с ID ${userId} не найден в базе данных`);
      return res.status(404).json({ 
        message: 'Пользователь не найден', 
        details: 'Пользователь, указанный в токене, не существует в базе данных'
      });
    }
    
    if (!user.isActive) {
      logger.warn(`Попытка получения информации о заблокированном пользователе: ${userId}`);
      return res.status(403).json({ 
        message: 'Аккаунт заблокирован', 
        details: 'Ваш аккаунт был заблокирован администратором'
      });
    }
    
    // Добавляем явную пометку о роли администратора для совместимости с фронтендом
    const userData = user.toJSON();
    userData.isAdmin = user.role === 'admin';
    
    logger.debug(`Успешное получение информации о пользователе: ${userId}, роль: ${user.role}, isAdmin: ${userData.isAdmin}`);
    
    res.json(userData);
  } catch (error) {
    logger.error(`Ошибка при получении информации о пользователе: ${error.message}`);
    next(error);
  }
};

/**
 * Обновление данных пользователя
 */
exports.updateProfile = async (req, res, next) => {
  try {
    const { name, password } = req.body;
    const userId = req.user.id;
    
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Обновление данных
    if (name) user.name = name;
    if (password) user.password = password;
    
    await user.save();
    
    logger.info(`Профиль пользователя обновлен: ${user.email}`);
    
    res.json({
      message: 'Профиль успешно обновлен',
      user: user.toJSON()
    });
  } catch (error) {
    logger.error(`Ошибка при обновлении профиля: ${error.message}`);
    next(error);
  }
};

/**
 * Получение списка всех пользователей (доступно только администраторам)
 */
exports.getAllUsers = async (req, res, next) => {
  try {
    // Проверка прав администратора
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Доступ запрещен. Требуются права администратора' });
    }
    
    const users = await User.findAll({
      attributes: { exclude: ['password'] }
    });
    
    logger.info(`Получен список пользователей администратором ${req.user.email}`);
    
    res.json(users);
  } catch (error) {
    logger.error(`Ошибка при получении списка пользователей: ${error.message}`);
    next(error);
  }
};

/**
 * Обновление роли пользователя (доступно только администраторам)
 */
exports.updateUserRole = async (req, res, next) => {
  try {
    // Проверка прав администратора
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Доступ запрещен. Требуются права администратора' });
    }
    
    const { userId } = req.params;
    const { role } = req.body;
    
    if (!role || !['user', 'manager', 'admin'].includes(role)) {
      return res.status(400).json({ message: 'Указана неверная роль' });
    }
    
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Обновление роли
    user.role = role;
    await user.save();
    
    logger.info(`Роль пользователя ${user.email} изменена на ${role}`);
    
    res.json({
      message: 'Роль пользователя успешно обновлена',
      user: {
        id: user.id,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    logger.error(`Ошибка при обновлении роли пользователя: ${error.message}`);
    next(error);
  }
};

/**
 * Обновление статуса активности пользователя (доступно только администраторам)
 */
exports.updateUserStatus = async (req, res, next) => {
  try {
    // Проверка прав администратора
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Доступ запрещен. Требуются права администратора' });
    }
    
    const { userId } = req.params;
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({ message: 'Статус активности должен быть boolean' });
    }
    
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Обновление статуса
    user.isActive = isActive;
    await user.save();
    
    logger.info(`Статус пользователя ${user.email} изменен на ${isActive ? 'активен' : 'неактивен'}`);
    
    res.json({
      message: `Пользователь ${isActive ? 'активирован' : 'деактивирован'}`,
      user: {
        id: user.id,
        email: user.email,
        isActive: user.isActive
      }
    });
  } catch (error) {
    logger.error(`Ошибка при обновлении статуса пользователя: ${error.message}`);
    next(error);
  }
}; 