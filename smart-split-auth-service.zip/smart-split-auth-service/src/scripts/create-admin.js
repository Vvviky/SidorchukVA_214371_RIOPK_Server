const { Sequelize } = require('sequelize');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Настройка подключения к базе данных
const sequelize = new Sequelize(
  process.env.DB_NAME || 'smart_split_auth',
  process.env.DB_USER || 'postgres',
  process.env.DB_PASSWORD || '12345',
  {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    dialect: 'postgres',
    logging: console.log
  }
);

// Импорт модели пользователя
const UserModel = require('../models/user.model')(sequelize);

async function createAdmin() {
  try {
    // Подключение к базе данных
    await sequelize.authenticate();
    console.log('Подключение к базе данных успешно установлено.');
    
    // Проверка на существование администратора с такой почтой
    const existingAdmin = await UserModel.findOne({ 
      where: { 
        email: 'admin@gmail.com'
      } 
    });
    
    if (existingAdmin) {
      console.log('Администратор с почтой admin@gmail.com уже существует.');
      return;
    }
    
    // Создание администратора
    const admin = await UserModel.create({
      firstName: 'Admin',
      lastName: 'Administrator',
      email: 'admin@gmail.com',
      password: 'admin123', // Будет захеширован с помощью хуков в модели
      role: 'admin',
      isActive: true,
      lastLogin: new Date()
    });
    
    console.log('Администратор успешно создан:');
    console.log('Email: admin@gmail.com');
    console.log('Пароль: admin123');
    console.log('Имя:', admin.firstName);
    console.log('Фамилия:', admin.lastName);
    console.log('ID:', admin.id);
    
  } catch (error) {
    console.error('Ошибка при создании администратора:', error);
  } finally {
    await sequelize.close();
    console.log('Соединение с базой данных закрыто.');
  }
}

// Запуск функции создания администратора
createAdmin(); 