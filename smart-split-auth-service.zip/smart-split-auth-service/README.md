# Auth Service

Сервис аутентификации и авторизации для системы Smart Split.

## Функциональность

- Регистрация и аутентификация пользователей
- Управление JWT токенами
- Управление пользователями (CRUD операции)
- Ролевая система доступа (RBAC)

## API Endpoints

### Аутентификация

#### POST /api/auth/register
Регистрация нового пользователя.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:**
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "USER",
  "token": "jwt-token"
}
```

#### POST /api/auth/login
Вход в систему.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "token": "jwt-token",
  "refreshToken": "refresh-token"
}
```

### Управление пользователями

#### GET /api/users
Получение списка пользователей (только для администраторов).

**Response:**
```json
{
  "users": [
    {
      "id": "uuid",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "USER",
      "isActive": true,
      "lastLogin": "2024-03-20T12:00:00Z"
    }
  ],
  "total": 1
}
```

## Безопасность

### JWT Токены

- Access Token: срок действия 1 час
- Refresh Token: срок действия 30 дней
- Хранение в httpOnly cookies
- Автоматическое обновление через refresh token

### Хеширование паролей

```javascript
const bcrypt = require('bcrypt');

const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
};

const verifyPassword = async (password, hash) => {
  return bcrypt.compare(password, hash);
};
```

### Middleware

#### Проверка аутентификации

```javascript
const verifyToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};
```

#### Проверка роли

```javascript
const checkRole = (roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Access denied' });
    }
    next();
  };
};
```

## Тестирование

### Unit Tests
- Тестирование хеширования паролей
- Тестирование генерации и валидации JWT токенов
- Тестирование middleware авторизации
- Тестирование валидации данных

### Integration Tests
- Тестирование регистрации пользователей
- Тестирование аутентификации
- Тестирование управления пользователями
- Тестирование обновления токенов

### Запуск тестов

```bash
# Установка зависимостей для тестирования
npm install --save-dev jest supertest @types/jest

# Запуск тестов
npm test

# Запуск тестов с отчетом о покрытии
npm run test:coverage
```

## Запуск

### Установка зависимостей

```bash
npm install
```

### Переменные окружения

Создайте файл `.env`:

```env
PORT=3001
JWT_SECRET=your-jwt-secret
REFRESH_TOKEN_SECRET=your-refresh-token-secret
DB_HOST=localhost
DB_PORT=5432
DB_NAME=auth_db
DB_USER=postgres
DB_PASSWORD=password
```

### Запуск сервера

```bash
# Development
npm run dev

# Production
npm start
```

### Запуск тестов

```bash
# Unit tests
npm run test

# Integration tests
npm run test:integration

# Coverage report
npm run test:coverage
``` 