'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    // Миграция отменена, поле не будет добавлено
    console.log('Миграция отменена. Вычисляем remainingAmount как totalAmount - paidAmount');
  },

  async down (queryInterface, Sequelize) {
    // Откат не требуется
    console.log('Откат не требуется');
  }
};
