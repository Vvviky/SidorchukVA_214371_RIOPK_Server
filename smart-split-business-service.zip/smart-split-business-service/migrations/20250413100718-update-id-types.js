'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // Изменение типа id в таблице Installments
    await queryInterface.changeColumn('Installments', 'id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4
    });

    // Изменение типа userId в таблице Installments
    await queryInterface.changeColumn('Installments', 'userId', {
      type: Sequelize.UUID,
      allowNull: false
    });

    // Изменение типа templateId в таблице Installments
    await queryInterface.changeColumn('Installments', 'templateId', {
      type: Sequelize.UUID,
      allowNull: true
    });
  },

  async down(queryInterface, Sequelize) {
    // Возврат типа id к INTEGER в таблице Installments
    await queryInterface.changeColumn('Installments', 'id', {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true
    });

    // Возврат типа userId к INTEGER в таблице Installments
    await queryInterface.changeColumn('Installments', 'userId', {
      type: Sequelize.INTEGER,
      allowNull: false
    });

    // Возврат типа templateId к INTEGER в таблице Installments
    await queryInterface.changeColumn('Installments', 'templateId', {
      type: Sequelize.INTEGER,
      allowNull: true
    });
  }
};
