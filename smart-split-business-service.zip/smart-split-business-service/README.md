# Business Service

Сервис бизнес-логики для системы Smart Split.

## Функциональность

- Управление шаблонами рассрочек
- Создание и управление рассрочками
- Расчет графиков платежей
- Обработка платежей
- Интеграция с платежными системами

## API Endpoints

### Шаблоны рассрочек

#### GET /api/templates
Получение списка шаблонов рассрочек.

**Response:**
```json
{
  "templates": [
    {
      "id": "uuid",
      "name": "Стандартная рассрочка",
      "description": "Рассрочка на 12 месяцев",
      "minAmount": 1000,
      "maxAmount": 100000,
      "availableTerms": [3, 6, 12],
      "defaultTerm": 12,
      "currency": "RUB",
      "requiresApproval": true,
      "isActive": true
    }
  ],
  "total": 1
}
```

#### POST /api/templates
Создание нового шаблона (только для администраторов).

**Request:**
```json
{
  "name": "Стандартная рассрочка",
  "description": "Рассрочка на 12 месяцев",
  "minAmount": 1000,
  "maxAmount": 100000,
  "availableTerms": [3, 6, 12],
  "defaultTerm": 12,
  "currency": "RUB",
  "requiresApproval": true
}
```

### Рассрочки

#### POST /api/installments
Создание новой рассрочки.

**Request:**
```json
{
  "templateId": "uuid",
  "amount": 50000,
  "term": 12,
  "title": "Покупка ноутбука",
  "description": "MacBook Pro 13"
}
```

**Response:**
```json
{
  "id": "uuid",
  "status": "PENDING_APPROVAL",
  "totalAmount": 50000,
  "term": 12,
  "monthlyPayment": 4166.67,
  "startDate": "2024-03-20T00:00:00Z",
  "endDate": "2025-03-20T00:00:00Z",
  "payments": [
    {
      "id": "uuid",
      "dueDate": "2024-04-20T00:00:00Z",
      "amount": 4166.67,
      "status": "PENDING"
    }
  ]
}
```

## Безопасность

### Валидация данных

```javascript
const validateInstallmentRequest = (data) => {
  const schema = Joi.object({
    templateId: Joi.string().uuid().required(),
    amount: Joi.number().min(1000).max(100000).required(),
    term: Joi.number().valid(3, 6, 12).required(),
    title: Joi.string().min(3).max(100).required(),
    description: Joi.string().max(500)
  });
  
  return schema.validate(data);
};
```

### Проверка прав доступа

```javascript
const checkInstallmentAccess = async (req, res, next) => {
  const installment = await Installment.findById(req.params.id);
  if (!installment) {
    return res.status(404).json({ message: 'Installment not found' });
  }
  
  if (req.user.role !== 'ADMIN' && installment.userId !== req.user.id) {
    return res.status(403).json({ message: 'Access denied' });
  }
  
  req.installment = installment;
  next();
};
```

### Безопасная обработка платежей

```javascript
const processPayment = async (installmentId, amount) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  
  try {
    const installment = await Installment.findById(installmentId).session(session);
    if (!installment) {
      throw new Error('Installment not found');
    }
    
    const payment = await Payment.create([{
      installmentId,
      amount,
      status: 'PROCESSING'
    }], { session });
    
    // Интеграция с платежной системой
    const paymentResult = await paymentGateway.processPayment({
      amount,
      currency: installment.currency,
      description: `Payment for installment ${installmentId}`
    });
    
    if (paymentResult.status === 'success') {
      payment.status = 'COMPLETED';
      installment.paidAmount += amount;
      
      if (installment.paidAmount >= installment.totalAmount) {
        installment.status = 'COMPLETED';
      }
      
      await payment.save({ session });
      await installment.save({ session });
      await session.commitTransaction();
      
      return { success: true, payment };
    } else {
      throw new Error('Payment failed');
    }
  } catch (error) {
    await session.abortTransaction();
    throw error;
  } finally {
    session.endSession();
  }
};
```

## Тестирование

### Unit Tests
- Тестирование расчета графика платежей
- Тестирование валидации данных рассрочки
- Тестирование обработки платежей
- Тестирование шаблонов рассрочек

### Integration Tests
- Тестирование создания рассрочек
- Тестирование управления рассрочками
- Тестирование платежных операций
- Тестирование шаблонов

### Запуск тестов

```bash
# Установка зависимостей для тестирования
npm install --save-dev jest supertest @types/jest

# Запуск тестов
npm test

# Запуск тестов с отчетом о покрытии
npm run test:coverage
```

## Запуск

### Установка зависимостей

```bash
npm install
```

### Переменные окружения

Создайте файл `.env`:

```env
PORT=3002
JWT_SECRET=same-as-auth-service
DB_HOST=localhost
DB_PORT=5432
DB_NAME=business_db
DB_USER=postgres
DB_PASSWORD=password
PAYMENT_GATEWAY_API_KEY=your-api-key
```

### Запуск сервера

```bash
# Development
npm run dev

# Production
npm start
```

### Запуск тестов

```bash
# Unit tests
npm run test

# Integration tests
npm run test:integration

# Coverage report
npm run test:coverage
``` 