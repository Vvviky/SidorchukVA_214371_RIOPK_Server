const logger = require('../utils/logger');
const { ApiError } = require('../utils/errors');

const errorHandler = (err, req, res, next) => {
  logger.error(err);

  if (err instanceof ApiError) {
    return res.status(err.status).json({
      message: err.message,
      errors: err.errors
    });
  }

  // Ошибки Sequelize
  if (err.name === 'SequelizeValidationError') {
    return res.status(400).json({
      message: 'Ошибка валидации',
      errors: err.errors.map(e => ({
        field: e.path,
        message: e.message
      }))
    });
  }

  if (err.name === 'SequelizeUniqueConstraintError') {
    return res.status(409).json({
      message: 'Запись уже существует',
      errors: err.errors.map(e => ({
        field: e.path,
        message: e.message
      }))
    });
  }

  // Ошибки базы данных
  if (err.name === 'SequelizeDatabaseError') {
    return res.status(400).json({
      message: 'Ошибка базы данных',
      error: err.message
    });
  }

  // Неизвестные ошибки
  return res.status(500).json({
    message: 'Внутренняя ошибка сервера',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
};

module.exports = errorHandler; 