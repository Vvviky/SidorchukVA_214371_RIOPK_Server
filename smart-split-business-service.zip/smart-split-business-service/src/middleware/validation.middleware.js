const { validationResult, body, param } = require('express-validator');

/**
 * Middleware для проверки результатов валидации
 */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: errors.array()[0].msg });
  }
  next();
};

/**
 * Валидация для создания рассрочки
 */
const validateCreateInstallment = (req, res, next) => {
  try {
    const { title, totalAmount, term } = req.body;

    if (!title) {
      return res.status(400).json({ message: 'Необходимо указать название рассрочки' });
    }

    if (!totalAmount || totalAmount <= 0) {
      return res.status(400).json({ message: 'Сумма рассрочки должна быть больше 0' });
    }

    if (!term || term <= 0) {
      return res.status(400).json({ message: 'Срок рассрочки должен быть больше 0' });
    }

    next();
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка валидации рассрочки' });
  }
};

/**
 * Валидация для создания платежа
 */
const validateCreatePayment = (req, res, next) => {
  try {
    const { installmentId, cardId, amount } = req.body;

    if (!installmentId) {
      return res.status(400).json({ message: 'Необходимо указать ID рассрочки' });
    }

    if (!cardId) {
      return res.status(400).json({ message: 'Необходимо указать ID карты' });
    }

    if (!amount || amount <= 0) {
      return res.status(400).json({ message: 'Сумма платежа должна быть больше 0' });
    }

    next();
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка валидации платежа' });
  }
};

/**
 * Валидация для расчета графика платежей
 */
const validateCalculatePaymentSchedule = [
  body('amount')
    .isFloat({ min: 100 }).withMessage('Сумма должна быть не менее 100'),
  body('term')
    .isInt({ min: 1, max: 60 }).withMessage('Срок должен быть от 1 до 60 месяцев'),
  validate
];

/**
 * Валидация ID рассрочки
 */
const validateInstallmentId = [
  param('id')
    .isInt().withMessage('Неверный формат ID рассрочки'),
  validate
];

/**
 * Валидация ID платежа
 */
const validatePaymentId = [
  param('id')
    .isUUID().withMessage('Неверный формат ID платежа'),
  validate
];

/**
 * Валидация для создания шаблона рассрочки
 */
const validateCreateTemplate = (req, res, next) => {
  try {
    const {
      name,
      minAmount,
      maxAmount,
      defaultAmount,
      availableTerms,
      defaultTerm,
      interestRate
    } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Необходимо указать название шаблона' });
    }

    if (!minAmount || minAmount <= 0) {
      return res.status(400).json({ message: 'Минимальная сумма должна быть больше 0' });
    }

    if (!maxAmount || maxAmount <= 0) {
      return res.status(400).json({ message: 'Максимальная сумма должна быть больше 0' });
    }

    if (maxAmount < minAmount) {
      return res.status(400).json({ message: 'Максимальная сумма должна быть больше минимальной' });
    }

    if (!defaultAmount || defaultAmount <= 0) {
      return res.status(400).json({ message: 'Сумма по умолчанию должна быть больше 0' });
    }

    if (defaultAmount < minAmount || defaultAmount > maxAmount) {
      return res.status(400).json({ message: 'Сумма по умолчанию должна быть в пределах от минимальной до максимальной' });
    }

    if (!availableTerms || !Array.isArray(availableTerms) || availableTerms.length === 0) {
      return res.status(400).json({ message: 'Необходимо указать доступные сроки' });
    }

    if (!defaultTerm || defaultTerm <= 0) {
      return res.status(400).json({ message: 'Срок по умолчанию должен быть больше 0' });
    }

    if (!availableTerms.includes(defaultTerm)) {
      return res.status(400).json({ message: 'Срок по умолчанию должен быть одним из доступных сроков' });
    }

    if (interestRate === undefined || interestRate < 0) {
      return res.status(400).json({ message: 'Процентная ставка должна быть больше или равна 0' });
    }

    next();
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка валидации шаблона' });
  }
};

/**
 * Валидация для обновления шаблона рассрочки
 */
const validateUpdateTemplate = (req, res, next) => {
  try {
    const {
      minAmount,
      maxAmount,
      defaultAmount,
      availableTerms,
      defaultTerm,
      interestRate
    } = req.body;

    if (minAmount !== undefined && minAmount <= 0) {
      return res.status(400).json({ message: 'Минимальная сумма должна быть больше 0' });
    }

    if (maxAmount !== undefined && maxAmount <= 0) {
      return res.status(400).json({ message: 'Максимальная сумма должна быть больше 0' });
    }

    if (minAmount !== undefined && maxAmount !== undefined && maxAmount < minAmount) {
      return res.status(400).json({ message: 'Максимальная сумма должна быть больше минимальной' });
    }

    if (defaultAmount !== undefined && defaultAmount <= 0) {
      return res.status(400).json({ message: 'Сумма по умолчанию должна быть больше 0' });
    }

    if (defaultAmount !== undefined && (defaultAmount < minAmount || defaultAmount > maxAmount)) {
      return res.status(400).json({ message: 'Сумма по умолчанию должна быть в пределах от минимальной до максимальной' });
    }

    if (availableTerms !== undefined && (!Array.isArray(availableTerms) || availableTerms.length === 0)) {
      return res.status(400).json({ message: 'Необходимо указать доступные сроки' });
    }

    if (defaultTerm !== undefined && defaultTerm <= 0) {
      return res.status(400).json({ message: 'Срок по умолчанию должен быть больше 0' });
    }

    if (defaultTerm !== undefined && availableTerms !== undefined && !availableTerms.includes(defaultTerm)) {
      return res.status(400).json({ message: 'Срок по умолчанию должен быть одним из доступных сроков' });
    }

    if (interestRate !== undefined && interestRate < 0) {
      return res.status(400).json({ message: 'Процентная ставка должна быть больше или равна 0' });
    }

    next();
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка валидации шаблона' });
  }
};

module.exports = {
  validate,
  validateCreateInstallment,
  validateCreatePayment,
  validateCalculatePaymentSchedule,
  validateInstallmentId,
  validatePaymentId,
  validateCreateTemplate,
  validateUpdateTemplate
}; 