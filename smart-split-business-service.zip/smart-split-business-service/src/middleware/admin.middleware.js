const { ApiError } = require('../utils/ApiError');

const adminMiddleware = (req, res, next) => {
  if (req.user.role !== 'admin') {
    throw ApiError.forbidden('Недостаточно прав для выполнения операции');
  }
  next();
};

module.exports = adminMiddleware; 