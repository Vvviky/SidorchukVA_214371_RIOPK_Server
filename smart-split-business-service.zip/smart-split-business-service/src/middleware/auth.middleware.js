const jwt = require('jsonwebtoken');
const axios = require('axios');
const logger = require('../utils/logger');
const { ApiError } = require('../utils/errors');

// Адрес сервиса аутентификации
const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || 'http://localhost:5000/api/auth';

/**
 * Middleware для проверки JWT токена
 */
const authMiddleware = async (req, res, next) => {
  try {
    // Получаем токен из заголовка Authorization
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      logger.warn('Отсутствует заголовок Authorization');
      return next(new ApiError(401, 'Требуется авторизация', 'Отсутствует токен'));
    }
    
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      logger.warn('Токен не найден в заголовке Authorization');
      return next(new ApiError(401, 'Требуется авторизация', 'Неверный формат токена'));
    }

    try {
      // Проверяем токен с использованием секретного ключа из переменных окружения
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Сохраняем информацию о пользователе в объекте запроса
      req.user = decoded;
      
      logger.debug(`Пользователь ${decoded.id} успешно аутентифицирован`);
      next();
    } catch (jwtError) {
      logger.warn(`Ошибка верификации JWT: ${jwtError.message}`);
      return next(new ApiError(401, 'Недействительный токен', jwtError.message));
    }
  } catch (error) {
    logger.error(`Ошибка в middleware аутентификации: ${error.message}`);
    next(error);
  }
};

/**
 * Middleware для проверки роли пользователя
 */
const authorize = (roles = []) => {
  if (typeof roles === 'string') {
    roles = [roles];
  }
  
  return (req, res, next) => {
    if (!req.user) {
      return next(new ApiError(401, 'Требуется авторизация', 'Пользователь не аутентифицирован'));
    }
    
    if (roles.length && !roles.includes(req.user.role)) {
      return next(new ApiError(403, 'Доступ запрещен', 'Недостаточно прав'));
    }
    
    next();
  };
};

// Экспортируем оба middleware
module.exports = authMiddleware;
module.exports.authorize = authorize; 