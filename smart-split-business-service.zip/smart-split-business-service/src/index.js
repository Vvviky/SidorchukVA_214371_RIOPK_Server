const express = require('express');
const cors = require('cors');
const config = require('./config');
const logger = require('./utils/logger');
const { initDatabase } = require('./models');
const errorHandler = require('./middleware/error.middleware');
const installmentRoutes = require('./routes/installment.routes');
const paymentRoutes = require('./routes/payment.routes');
const calculationRoutes = require('./routes/calculation.routes');
const templateRoutes = require('./routes/installmentTemplate.routes');
const transactionRoutes = require('./routes/transaction.routes');
const cardRoutes = require('./routes/card.routes');

const app = express();

 
app.use(cors(config.cors));
app.use(express.json());

 
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

 
app.use('/api/installments', installmentRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/calculations', calculationRoutes);
app.use('/api/templates', templateRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/cards', cardRoutes);

 
app.use(errorHandler);

const startServer = async () => {
  try {
     
    await initDatabase(false); // false - не пересоздавать таблицы при каждом запуске

     
    app.listen(config.server.port, () => {
      logger.info(`Сервер запущен на порту ${config.server.port}`);
    });
  } catch (error) {
    logger.error('Ошибка при запуске сервера:', error);
    process.exit(1);
  }
};

startServer(); 