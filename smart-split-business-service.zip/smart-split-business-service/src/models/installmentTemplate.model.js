const { DataTypes } = require('sequelize');

/**
 * Модель шаблона рассрочки
 */
module.exports = (sequelize) => {
  const InstallmentTemplate = sequelize.define('InstallmentTemplate', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'Название шаблона обязательно'
        },
        len: {
          args: [3, 100],
          msg: 'Название должно содержать от 3 до 100 символов'
        }
      }
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
      validate: {
        len: {
          args: [0, 500],
          msg: 'Описание не должно превышать 500 символов'
        }
      }
    },
    minAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: {
          args: [100],
          msg: 'Минимальная сумма должна быть не менее 100'
        }
      }
    },
    maxAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: {
          args: [100],
          msg: 'Максимальная сумма должна быть не менее 100'
        },
        isGreaterThanMinAmount(value) {
          if (value < this.minAmount) {
            throw new Error('Максимальная сумма должна быть больше или равна минимальной');
          }
        }
      }
    },
    defaultAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: {
          args: [100],
          msg: 'Сумма по умолчанию должна быть не менее 100'
        },
        isWithinRange(value) {
          if (value < this.minAmount || value > this.maxAmount) {
            throw new Error('Сумма по умолчанию должна быть в пределах от минимальной до максимальной');
          }
        }
      }
    },
    availableTerms: {
      type: DataTypes.ARRAY(DataTypes.INTEGER),
      allowNull: false,
      validate: {
        isValidTermsArray(value) {
          if (!Array.isArray(value) || value.length === 0) {
            throw new Error('Должен быть указан хотя бы один доступный срок');
          }
          
          if (!value.every(term => Number.isInteger(term) && term >= 1 && term <= 60)) {
            throw new Error('Доступные сроки должны быть в пределах от 1 до 60 месяцев');
          }
        }
      }
    },
    defaultTerm: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: {
          args: [1],
          msg: 'Срок по умолчанию должен быть не менее 1 месяца'
        },
        max: {
          args: [60],
          msg: 'Срок по умолчанию должен быть не более 60 месяцев'
        },
        isInAvailableTerms(value) {
          if (!this.availableTerms.includes(value)) {
            throw new Error('Срок по умолчанию должен быть одним из доступных сроков');
          }
        }
      }
    },
    interestRate: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: false,
      validate: {
        min: {
          args: [0],
          msg: 'Процентная ставка не может быть отрицательной'
        },
        max: {
          args: [100],
          msg: 'Процентная ставка не может превышать 100%'
        }
      }
    },
    currency: {
      type: DataTypes.ENUM('BYN', 'USD', 'EUR', 'RUB'),
      defaultValue: 'BYN'
    },
    requiresApproval: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    category: {
      type: DataTypes.ENUM('Бытовая техника', 'Электроника', 'Мебель', 'Образование', 'Путешествия', 'Другое'),
      defaultValue: 'Другое'
    },
    createdBy: {
      type: DataTypes.STRING,
      allowNull: false
    },
    updatedBy: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    timestamps: true,
    hooks: {
      beforeDestroy: async (template, options) => {
        // Проверка, можно ли удалить шаблон
        const { Installment } = require('./index');
        const count = await Installment.count({
          where: { templateId: template.id }
        });
        
        if (count > 0) {
          throw new Error('Невозможно удалить шаблон, так как существуют связанные с ним рассрочки');
        }
      }
    }
  });

  // Дополнительные методы
  InstallmentTemplate.prototype.canBeDeleted = async function() {
    const { Installment } = require('./index');
    const count = await Installment.count({
      where: { templateId: this.id }
    });
    return count === 0;
  };

  // Статический метод для поиска активных шаблонов
  InstallmentTemplate.findActiveTemplates = function() {
    return this.findAll({
      where: { isActive: true },
      order: [['createdAt', 'DESC']]
    });
  };

  return InstallmentTemplate;
}; 