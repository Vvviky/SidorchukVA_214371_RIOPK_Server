const { DataTypes } = require('sequelize');

/**
 * Модель платежа по рассрочке
 */
module.exports = (sequelize) => {
  const Payment = sequelize.define('Payment', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    installmentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Installments',
        key: 'id'
      }
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: 0
      }
    },
    dueDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('pending', 'paid', 'overdue', 'cancelled'),
      allowNull: false,
      defaultValue: 'pending'
    },
    paidAt: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['installmentId']
      },
      {
        fields: ['status']
      },
      {
        fields: ['dueDate']
      }
    ]
  });

  return Payment;
}; 