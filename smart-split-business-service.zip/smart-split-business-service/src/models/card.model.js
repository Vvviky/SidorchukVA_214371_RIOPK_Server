const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Card = sequelize.define('Card', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    cardNumber: {
      type: DataTypes.STRING(16),
      allowNull: false,
      unique: true
    },
    cardHolder: {
      type: DataTypes.STRING,
      allowNull: false
    },
    expiryDate: {
      type: DataTypes.STRING(5),
      allowNull: false
    },
    cvv: {
      type: DataTypes.STRING(3),
      allowNull: false
    },
    balance: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      defaultValue: 0,
      validate: {
        min: 0
      }
    },
    isDefault: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    status: {
      type: DataTypes.ENUM('active', 'blocked'),
      allowNull: false,
      defaultValue: 'active'
    }
  }, {
    timestamps: true,
    hooks: {
      beforeCreate: async (card) => {
        // Генерируем случайный баланс от 1000 до 10000
        card.balance = Math.floor(Math.random() * (10000 - 1000 + 1)) + 1000;
      }
    }
  });

  return Card;
}; 