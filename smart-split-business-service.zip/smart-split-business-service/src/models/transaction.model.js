const { DataTypes } = require('sequelize');

/**
 * Модель истории операций
 * Хранит все события, связанные с рассрочками и платежами
 */
module.exports = (sequelize) => {
  const Transaction = sequelize.define('Transaction', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    installmentId: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    paymentId: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    type: {
      type: DataTypes.ENUM(
        'installment_created',
        'installment_activated',
        'installment_cancelled',
        'installment_completed',
        'installment_rejected',
        'payment_created',
        'payment_made',
        'schedule_updated',
        'card_created',
        'card_deleted',
        'card_updated',
        'installment_created_from_template'
      ),
      allowNull: false
    },
    details: {
      type: DataTypes.JSONB,
      allowNull: true,
      comment: 'Дополнительная информация о транзакции'
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW
    }
  }, {
    timestamps: true,
    updatedAt: false,
    indexes: [
      {
        fields: ['userId']
      },
      {
        fields: ['installmentId']
      },
      {
        fields: ['paymentId']
      },
      {
        fields: ['type']
      },
      {
        fields: ['createdAt']
      }
    ]
  });

  return Transaction;
}; 