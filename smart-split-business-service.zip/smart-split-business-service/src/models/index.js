const { Sequelize } = require('sequelize');
const config = require('../config');
const logger = require('../utils/logger');

const sequelize = new Sequelize(
  config.database.name,
  config.database.user,
  config.database.password,
  {
    host: config.database.host,
    dialect: 'postgres',
    logging: (msg) => logger.debug(msg)
  }
);

// Импорт моделей
const Installment = require('./installment.model')(sequelize);
const Transaction = require('./transaction.model')(sequelize);
const Payment = require('./payment.model')(sequelize);
const PaymentSchedule = require('./paymentSchedule.model')(sequelize);
const InstallmentTemplate = require('./installmentTemplate.model')(sequelize);
const Card = require('./card.model')(sequelize);

// Определение связей
Installment.hasMany(Payment, { as: 'payments', foreignKey: 'installmentId' });
Payment.belongsTo(Installment, { foreignKey: 'installmentId' });

Installment.hasMany(PaymentSchedule, { as: 'schedules', foreignKey: 'installmentId' });
PaymentSchedule.belongsTo(Installment, { foreignKey: 'installmentId' });

// Новая связь между шаблоном и рассрочкой
InstallmentTemplate.hasMany(Installment, { foreignKey: 'templateId', as: 'installments' });
Installment.belongsTo(InstallmentTemplate, { foreignKey: 'templateId', as: 'template' });

// Связи для истории операций
Installment.hasMany(Transaction, { foreignKey: 'installmentId', as: 'transactions', onDelete: 'CASCADE' });
Transaction.belongsTo(Installment, { foreignKey: 'installmentId', as: 'installment' });

Payment.hasOne(Transaction, { foreignKey: 'paymentId', onDelete: 'CASCADE' });
Transaction.belongsTo(Payment, { foreignKey: 'paymentId', as: 'payment' });

// Связи для карт
Card.hasMany(Payment, { foreignKey: 'cardId', as: 'payments', onDelete: 'SET NULL' });
Payment.belongsTo(Card, { foreignKey: 'cardId', as: 'card' });

// Функция инициализации базы данных
const initDatabase = async (force = false) => {
  try {
    // Синхронизация моделей с базой данных
    // force: true - пересоздает таблицы
    await sequelize.sync({ force });
    logger.info('База данных успешно инициализирована');
  } catch (error) {
    logger.error('Ошибка при инициализации базы данных:', error);
    throw error;
  }
};

module.exports = {
  sequelize,
  Installment,
  Transaction,
  Payment,
  PaymentSchedule,
  InstallmentTemplate,
  Card,
  initDatabase
}; 