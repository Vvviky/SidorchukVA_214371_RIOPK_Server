const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Installment = sequelize.define('Installment', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    templateId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'ID шаблона рассрочки, если рассрочка создана на основе шаблона'
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    totalAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: 0
      }
    },
    paidAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      defaultValue: 0,
      validate: {
        min: 0
      }
    },
    term: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Срок рассрочки в месяцах'
    },
    status: {
      type: DataTypes.ENUM('pending', 'active', 'completed', 'cancelled', 'rejected'),
      defaultValue: 'pending'
    },
    startDate: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Дата начала рассрочки'
    },
    endDate: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Предполагаемая дата окончания рассрочки'
    },
    completedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Фактическая дата завершения рассрочки'
    },
    nextPaymentDate: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Дата следующего платежа'
    },
    nextPaymentAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      comment: 'Сумма следующего платежа'
    },
    interestRate: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: false,
      defaultValue: 0,
      comment: 'Процентная ставка для данной рассрочки'
    },
    rejectionReason: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: 'Причина отклонения рассрочки администратором'
    }
  }, {
    timestamps: true,
    hooks: {
      beforeCreate: (installment) => {
        // Если статус "active", устанавливаем startDate
        if (installment.status === 'active' && !installment.startDate) {
          installment.startDate = new Date();
          
          // Рассчитываем endDate (startDate + term месяцев)
          const endDate = new Date(installment.startDate);
          endDate.setMonth(endDate.getMonth() + installment.term);
          installment.endDate = endDate;
        }
      },
      beforeUpdate: (installment) => {
        // Если изменился статус на "active", устанавливаем startDate
        if (installment.changed('status') && installment.status === 'active' && !installment.startDate) {
          installment.startDate = new Date();
          
          // Рассчитываем endDate (startDate + term месяцев)
          const endDate = new Date(installment.startDate);
          endDate.setMonth(endDate.getMonth() + installment.term);
          installment.endDate = endDate;
        }
        
        // Если изменился статус на "completed", устанавливаем completedAt
        if (installment.changed('status') && installment.status === 'completed' && !installment.completedAt) {
          installment.completedAt = new Date();
        }
        
        // Если paidAmount >= totalAmount, статус меняем на "completed"
        if (installment.paidAmount >= installment.totalAmount && installment.status !== 'completed') {
          installment.status = 'completed';
          installment.completedAt = new Date();
        }
      }
    }
  });

  return Installment;
}; 