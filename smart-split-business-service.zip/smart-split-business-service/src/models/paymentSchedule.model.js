const { DataTypes } = require('sequelize');

/**
 * Модель графика платежей
 */
module.exports = (sequelize) => {
  const PaymentSchedule = sequelize.define('PaymentSchedule', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    installmentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Installments',
        key: 'id'
      }
    },
    paymentNumber: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Порядковый номер платежа'
    },
    plannedDate: {
      type: DataTypes.DATE,
      allowNull: false,
      comment: 'Планируемая дата платежа'
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: 0
      }
    },
    isPaid: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    actualPaymentDate: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Фактическая дата, когда был произведен платеж'
    },
    paymentId: {
      type: DataTypes.UUID,
      allowNull: true,
      comment: 'ID платежа, которым был оплачен этот график'
    }
  }, {
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['installmentId', 'paymentNumber']
      }
    ]
  });

  return PaymentSchedule;
}; 