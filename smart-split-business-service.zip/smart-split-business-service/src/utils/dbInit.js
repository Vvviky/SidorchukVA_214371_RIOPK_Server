const { sequelize } = require('../models');
const logger = require('./logger');

async function initializeDatabase() {
  try {
    // Синхронизация моделей с базой данных
    await sequelize.sync({ alter: true });
    
    logger.info('База данных успешно инициализирована');
    
    // Здесь можно добавить создание начальных данных, если нужно
    // await seedInitialData();
    
  } catch (error) {
    logger.error('Ошибка при инициализации базы данных:', error);
    throw error;
  }
}

// Функция для создания начальных данных (если потребуется)
async function seedInitialData() {
  // Тут можно добавить создание тестовых шаблонов рассрочки и т.д.
}

module.exports = {
  initializeDatabase
}; 