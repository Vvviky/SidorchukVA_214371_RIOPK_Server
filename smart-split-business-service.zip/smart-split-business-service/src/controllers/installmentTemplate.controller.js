const logger = require('../utils/logger');
const { InstallmentTemplate } = require('../models');
const { NotFoundError, ForbiddenError, ApiError } = require('../utils/errors');
const transactionController = require('./transaction.controller');

/**
 * Получить все активные шаблоны рассрочек
 */
const getAllTemplates = async (req, res, next) => {
  try {
    const templates = await InstallmentTemplate.findAll({
      order: [['createdAt', 'DESC']]
    });
    console.log('teplates: ', templates);
    
    res.json(templates);
  } catch (error) {
    next(error);
  }
};

/**
 * Получить шаблон рассрочки по ID
 */
const getTemplateById = async (req, res, next) => {
  try {
    const template = await InstallmentTemplate.findByPk(req.params.id);
    
    if (!template) {
      throw new ApiError(404, 'Шаблон не найден');
    }
    
    res.json(template);
  } catch (error) {
    next(error);
  }
};

/**
 * Создать новый шаблон рассрочки (только администратор)
 */
const createTemplate = async (req, res, next) => {
  try {
    const template = await InstallmentTemplate.create({
      ...req.body,
      createdBy: req.user.id
    });
    
    res.status(201).json(template);
  } catch (error) {
    next(error);
  }
};

/**
 * Обновить существующий шаблон рассрочки (только администратор)
 */
const updateTemplate = async (req, res, next) => {
  try {
    const template = await InstallmentTemplate.findByPk(req.params.id);
    
    if (!template) {
      throw new ApiError(404, 'Шаблон не найден');
    }
    
    // Проверка, можно ли обновить шаблон
    if (!template.isActive && req.body.isActive) {
      const canBeActivated = await template.canBeDeleted();
      if (!canBeActivated) {
        throw new ApiError(400, 'Невозможно активировать шаблон, так как существуют связанные с ним рассрочки');
      }
    }
    
    await template.update({
      ...req.body,
      updatedBy: req.user.id
    });
    
    res.json(template);
  } catch (error) {
    next(error);
  }
};

/**
 * Изменить статус шаблона рассрочки (активен/неактивен)
 */
const toggleTemplateStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;

    const template = await InstallmentTemplate.findByPk(id);
    
    if (!template) {
      throw new NotFoundError('Шаблон рассрочки не найден');
    }

    // Обновляем статус
    await template.update({
      isActive,
      updatedBy: req.user.id
    });

    // Получаем обновленный шаблон
    const updatedTemplate = await InstallmentTemplate.findByPk(id);

    // Запись в историю операций
    await transactionController.createTransaction('template_status_changed', req.user.id, {
      templateId: template.id,
      name: template.name,
      isActive: template.isActive
    });

    res.status(200).json({
      success: true,
      message: `Шаблон рассрочки ${isActive ? 'активирован' : 'деактивирован'}`,
      data: updatedTemplate
    });
  } catch (error) {
    logger.error(`Ошибка при изменении статуса шаблона рассрочки ID ${req.params.id}:`, error);
    next(error);
  }
};

/**
 * Удалить шаблон рассрочки (только администратор)
 */
const deleteTemplate = async (req, res, next) => {
  try {
    const template = await InstallmentTemplate.findByPk(req.params.id);
    
    if (!template) {
      throw new ApiError(404, 'Шаблон не найден');
    }
    
    // Проверка возможности удаления
    const canBeDeleted = await template.canBeDeleted();
    if (!canBeDeleted) {
      throw new ApiError(400, 'Невозможно удалить шаблон, так как существуют связанные с ним рассрочки');
    }
    
    await template.destroy();
    
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

/**
 * Получение списка активных шаблонов
 */
const getActiveTemplates = async (req, res, next) => {
  try {
    logger.info('Fetching active installment templates');
    
    const templates = await InstallmentTemplate.findAll({
      where: { isActive: true },
      order: [['createdAt', 'DESC']]
    });
    
    logger.info(`Found ${templates.length} active templates`);
    return res.status(200).json(templates);
  } catch (error) {
    logger.error(`Error fetching active templates: ${error.message}`);
    return next(new ApiError(500, 'Failed to fetch active templates'));
  }
};

module.exports = {
  getAllTemplates,
  getTemplateById,
  createTemplate,
  updateTemplate,
  toggleTemplateStatus,
  deleteTemplate,
  getActiveTemplates
}; 