const { Installment, Payment, PaymentSchedule, sequelize, Card, Transaction } = require('../models');
const logger = require('../utils/logger');
const { ApiError } = require('../utils/errors');
const paymentService = require('../services/payment.service');
const transactionController = require('./transaction.controller');

class PaymentController {
  /**
   * Получение всех платежей по рассрочке
   */
  async getInstallmentPayments(req, res, next) {
    try {
      const { installmentId } = req.params;
      const userId = req.user.id;
      
      // Проверка существования рассрочки и прав доступа
      const installment = await Installment.findOne({
        where: { id: installmentId, userId }
      });
      
      if (!installment) {
        throw new ApiError(404, 'Рассрочка не найдена');
      }
      
      const payments = await Payment.findAll({
        where: { installmentId },
        order: [['dueDate', 'ASC']]
      });
      
      res.json(payments);
    } catch (error) {
      logger.error(`Ошибка при получении платежей: ${error.message}`);
      next(error);
    }
  }

  /**
   * Создание нового платежа
   */
  async createPayment(req, res, next) {
    try {
      const { installmentId, amount } = req.body;
      
      logger.info(`Запрос на создание платежа: installmentId=${installmentId}, amount=${amount}`);
      
      // Находим рассрочку
      const installment = await Installment.findByPk(installmentId);
      if (!installment) {
        throw new ApiError(404, 'Рассрочка не найдена');
      }
      
      logger.info(`Найдена рассрочка: id=${installment.id}, title=${installment.title}, totalAmount=${installment.totalAmount}, paidAmount=${installment.paidAmount}`);
      
      // Проверяем статус рассрочки
      if (installment.status !== 'active' && installment.status !== 'approved') {
        throw new ApiError(400, 'Невозможно произвести платеж по неактивной рассрочке');
      }
      
      // Проверяем, что сумма платежа не превышает оставшуюся сумму
      const remainingAmount = installment.totalAmount - installment.paidAmount;
      if (amount > remainingAmount) {
        throw new ApiError(400, `Сумма платежа превышает оставшуюся сумму рассрочки (${remainingAmount})`);
      }
      
      // Создаем платеж
      const payment = await Payment.create({
        installmentId,
        amount,
        dueDate: new Date(), // Текущая дата как срок оплаты
        status: 'paid',
        paidAt: new Date()
      });
      
      logger.info(`Платеж создан: id=${payment.id}, amount=${payment.amount}`);
      
      // Обновляем оплаченную сумму в рассрочке
      const oldPaidAmount = installment.paidAmount;
      installment.paidAmount = Number(oldPaidAmount) + Number(amount);
      
      logger.info(`Обновление paidAmount: ${oldPaidAmount} -> ${installment.paidAmount}`);
      
      // Если оплаченная сумма достигла или превысила общую сумму, меняем статус на "completed"
      if (installment.paidAmount >= installment.totalAmount) {
        const oldStatus = installment.status;
        installment.status = 'completed';
        installment.completedAt = new Date();
        logger.info(`Изменение статуса рассрочки: ${oldStatus} -> ${installment.status}`);
      }
      
      try {
        // Принудительно сохраняем изменения в рассрочке
        await installment.save({ fields: ['paidAmount', 'status', 'completedAt'] });
        logger.info(`Рассрочка успешно обновлена: id=${installment.id}, paidAmount=${installment.paidAmount}, status=${installment.status}`);
        
        // Дополнительно проверяем успешность обновления
        const checkInstallment = await Installment.findByPk(installmentId);
        logger.info(`Проверка обновления: id=${checkInstallment.id}, paidAmount=${checkInstallment.paidAmount}, status=${checkInstallment.status}`);
      } catch (saveError) {
        logger.error(`Ошибка при сохранении рассрочки: ${saveError.message}`);
        // Попробуем обновить запись напрямую через update
        await Installment.update(
          {
            paidAmount: installment.paidAmount,
            status: installment.status,
            completedAt: installment.completedAt
          },
          { where: { id: installmentId } }
        );
        logger.info(`Рассрочка обновлена через метод update: id=${installmentId}, paidAmount=${installment.paidAmount}`);
      }
      
      // Запись в историю операций
      await transactionController.createTransaction('payment_made', req.user?.id || 'system', {
        installmentId,
        paymentId: payment.id,
        amount,
        remainingAmount: installment.totalAmount - installment.paidAmount
      });
      
      logger.info(`Платеж успешно создан: ${payment.id}, рассрочка: ${installmentId}, сумма: ${amount}`);
      
      res.status(201).json({ 
        data: payment,
        installment: {
          id: installment.id,
          totalAmount: installment.totalAmount,
          paidAmount: installment.paidAmount,
          remainingAmount: installment.totalAmount - installment.paidAmount,
          status: installment.status
        }
      });
    } catch (err) {
      logger.error(`Ошибка при создании платежа: ${err.message}`);
      next(err);
    }
  }

  /**
   * Получение графика платежей по рассрочке
   */
  async getPaymentSchedule(req, res, next) {
    try {
      const { installmentId } = req.params;
      
      // Проверка существования рассрочки
      const installment = await Installment.findByPk(installmentId);
      
      if (!installment) {
        logger.warn(`Запрошен график платежей для несуществующей рассрочки: ${installmentId}`);
        return res.status(404).json({ 
          message: 'Рассрочка не найдена', 
          details: 'Невозможно получить график платежей для несуществующей рассрочки' 
        });
      }
      
      // Проверка прав доступа
      const userId = req.user?.id;
      const isAdmin = req.user?.role === 'admin';
      
      if (!isAdmin && installment.userId !== userId) {
        logger.warn(`Попытка доступа к графику платежей чужой рассрочки: пользователь ${userId}, рассрочка ${installmentId}`);
        return res.status(403).json({ 
          message: 'Доступ запрещен', 
          details: 'У вас нет прав на просмотр графика платежей этой рассрочки' 
        });
      }
      
      // Получаем график платежей
      const schedules = await PaymentSchedule.findAll({
        where: { installmentId },
        order: [['paymentNumber', 'ASC']]
      });
      
      logger.info(`Получен график платежей для рассрочки ${installmentId}, найдено ${schedules.length} записей`);
      
      res.json({ data: schedules });
    } catch (error) {
      logger.error(`Ошибка при получении графика платежей: ${error.message}`);
      next(error);
    }
  }

  // Получение списка платежей пользователя
  async getUserPayments(req, res, next) {
    try {
      const userId = req.user?.id || 'system';
      
      const payments = await Payment.findAll({
        include: [{
          model: Installment,
          where: { userId },
          attributes: ['id', 'title', 'userId']
        }],
        order: [['createdAt', 'DESC']]
      });
      
      res.json({ data: payments });
    } catch (err) {
      logger.error(`Ошибка при получении платежей пользователя: ${err.message}`);
      next(err);
    }
  }

  // Получение деталей платежа
  async getPaymentDetails(req, res, next) {
    try {
      const { id } = req.params;

      const payment = await Payment.findOne({
        where: { id },
        include: [
          {
            model: Installment,
            where: { userId: req.user.id },
            attributes: ['id', 'title', 'totalAmount']
          }
        ]
      });

      if (!payment) {
        throw new ApiError(404, 'Платеж не найден');
      }

      res.json(payment);
    } catch (error) {
      next(error);
    }
  }

  async getPaymentsByInstallmentId(req, res, next) {
    try {
      const { installmentId } = req.params;
      const payments = await paymentService.getPaymentsByInstallmentId(installmentId);
      res.json(payments);
    } catch (error) {
      next(error);
    }
  }

  async updatePaymentStatus(req, res, next) {
    try {
      const { paymentId } = req.params;
      const { status } = req.body;
      
      if (!status || !['pending', 'paid', 'overdue', 'cancelled'].includes(status)) {
        throw new ApiError(400, 'Указан неверный статус платежа');
      }
      
      const payment = await paymentService.updatePaymentStatus(paymentId, status);
      logger.info(`Обновлен статус платежа ${paymentId}: ${status}`);
      res.json(payment);
    } catch (error) {
      next(error);
    }
  }

  async getOverduePayments(req, res, next) {
    try {
      const payments = await paymentService.getOverduePayments();
      res.json(payments);
    } catch (error) {
      next(error);
    }
  }

  /**
   * Получение всех платежей (для администратора)
   */
  async getAllPayments(req, res, next) {
    try {
      const { installmentId, status, fromDate, toDate } = req.query;
      
      const where = {};
      
      if (installmentId) {
        where.installmentId = installmentId;
      }
      
      if (status) {
        where.status = status;
      }
      
      // Фильтр по датам
      if (fromDate || toDate) {
        where.createdAt = {};
        
        if (fromDate) {
          where.createdAt.$gte = new Date(fromDate);
        }
        
        if (toDate) {
          where.createdAt.$lte = new Date(toDate);
        }
      }
      
      const payments = await Payment.findAll({
        where,
        include: [{
          model: Installment,
          attributes: ['id', 'title', 'userId']
        }],
        order: [['createdAt', 'DESC']]
      });
      
      res.json({ data: payments });
    } catch (err) {
      logger.error(`Ошибка при получении всех платежей: ${err.message}`);
      next(err);
    }
  }
}

module.exports = new PaymentController(); 