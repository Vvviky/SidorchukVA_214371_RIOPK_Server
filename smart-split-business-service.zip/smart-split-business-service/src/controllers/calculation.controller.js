const { calculateMonthlyPayment, calculatePaymentSchedule, calculateOverpayment } = require('../services/calculationService');
const { ApiError } = require('../utils/ApiError');
const logger = require('../utils/logger');

/**
 * Расчет ежемесячного платежа
 */
exports.calculateMonthlyPayment = async (req, res, next) => {
  try {
    const { amount, term, interestRate } = req.body;
    
    if (!amount || !term || !interestRate) {
      throw ApiError.badRequest('Необходимо указать сумму, срок и процентную ставку');
    }
    
    const totalAmount = parseFloat(amount);
    const months = parseInt(term);
    const rate = parseFloat(interestRate);
    
    // Расчет ежемесячного платежа
    const monthlyPayment = calculateMonthlyPayment(totalAmount, months, rate);
    
    res.json({
      totalAmount,
      term: months,
      interestRate: rate,
      monthlyPayment
    });
  } catch (error) {
    logger.error(`Ошибка при расчете ежемесячного платежа: ${error.message}`);
    next(error);
  }
};

/**
 * Расчет графика платежей
 */
exports.calculatePaymentSchedule = async (req, res, next) => {
  try {
    const { amount, term, interestRate } = req.body;
    
    if (!amount || !term || !interestRate) {
      throw ApiError.badRequest('Необходимо указать сумму, срок и процентную ставку');
    }
    
    const totalAmount = parseFloat(amount);
    const months = parseInt(term);
    const rate = parseFloat(interestRate);
    
    // Генерация графика платежей
    const schedule = calculatePaymentSchedule(totalAmount, months, rate);
    
    // Расчет ежемесячного платежа и переплаты
    const monthlyPayment = calculateMonthlyPayment(totalAmount, months, rate);
    const overpayment = calculateOverpayment(totalAmount, months, rate);
    
    res.json({
      totalAmount,
      term: months,
      interestRate: rate,
      monthlyPayment,
      schedule,
      overpayment
    });
  } catch (error) {
    logger.error(`Ошибка при расчете графика платежей: ${error.message}`);
    next(error);
  }
};

/**
 * Получение информации о рассрочке
 */
exports.getInstallmentInfo = async (req, res, next) => {
  try {
    const { totalAmount, paidAmount, term, interestRate } = req.body;
    
    if (!totalAmount || !paidAmount || !term || !interestRate) {
      throw ApiError.badRequest('Необходимо указать общую сумму, выплаченную сумму, срок и процентную ставку');
    }
    
    const total = parseFloat(totalAmount);
    const paid = parseFloat(paidAmount);
    const months = parseInt(term);
    const rate = parseFloat(interestRate);
    
    const remainingAmount = total - paid;
    const progress = (paid / total) * 100;
    const monthlyPayment = calculateMonthlyPayment(total, months, rate);
    
    res.json({
      totalAmount: total,
      paidAmount: paid,
      remainingAmount,
      progress,
      monthlyPayment,
      term: months,
      interestRate: rate
    });
  } catch (error) {
    logger.error(`Ошибка при получении информации о рассрочке: ${error.message}`);
    next(error);
  }
};

/**
 * Расчет максимальной суммы кредита
 */
exports.calculateMaxAmount = async (req, res, next) => {
  try {
    const { monthlyIncome, monthlyExpenses, term, interestRate } = req.body;

    if (!monthlyIncome || !term || !interestRate) {
      throw ApiError.badRequest('Необходимо указать ежемесячный доход, срок и процентную ставку');
    }

    const income = parseFloat(monthlyIncome);
    const expenses = parseFloat(monthlyExpenses) || 0;
    const months = parseInt(term);
    const rate = parseFloat(interestRate);

    const availablePayment = income - expenses;
    if (availablePayment <= 0) {
      throw ApiError.badRequest('Доступная сумма ежемесячного платежа должна быть больше нуля');
    }

    // Расчет максимальной суммы кредита (используя формулу аннуитетного платежа)
    const monthlyRate = rate / 12 / 100;
    const maxAmount = Math.round(availablePayment * (1 - Math.pow(1 + monthlyRate, -months)) / monthlyRate * 100) / 100;

    const monthlyPayment = calculateMonthlyPayment(maxAmount, months, rate);
    const overpayment = calculateOverpayment(maxAmount, months, rate);

    res.json({
      maxAmount,
      monthlyPayment,
      availablePayment,
      term: months,
      interestRate: rate,
      overpayment
    });
  } catch (error) {
    logger.error(`Ошибка при расчете максимальной суммы кредита: ${error.message}`);
    next(error);
  }
};

module.exports = {
  calculateMonthlyPayment: exports.calculateMonthlyPayment,
  calculatePaymentSchedule: exports.calculatePaymentSchedule,
  calculateMaxAmount: exports.calculateMaxAmount,
  getInstallmentInfo: exports.getInstallmentInfo
}; 