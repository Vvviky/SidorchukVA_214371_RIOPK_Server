const { Transaction, Installment, Payment, Card } = require('../models');
const { ApiError } = require('../utils/errors');
const logger = require('../utils/logger');

/**
 * Получение истории операций пользователя
 */
exports.getUserTransactions = async (req, res, next) => {
  try {
    const transactions = await Transaction.findAll({
      where: { userId: req.user.id },
      include: [
        {
          model: Installment,
          attributes: ['id', 'title', 'status']
        },
        {
          model: Payment,
          attributes: ['id', 'amount', 'paymentDate'],
          include: [
            {
              model: Card,
              attributes: ['id', 'cardNumber']
            }
          ]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(transactions);
  } catch (error) {
    logger.error(`Ошибка при получении истории операций: ${error.message}`);
    next(error);
  }
};

/**
 * Получение истории операций по конкретной рассрочке
 */
exports.getInstallmentTransactions = async (req, res, next) => {
  try {
    const { installmentId } = req.params;

    const installment = await Installment.findOne({
      where: { id: installmentId, userId: req.user.id }
    });

    if (!installment) {
      throw new ApiError(404, 'Рассрочка не найдена');
    }

    const transactions = await Transaction.findAll({
      where: { installmentId },
      include: [
        {
          model: Payment,
          attributes: ['id', 'amount', 'paymentDate'],
          include: [
            {
              model: Card,
              attributes: ['id', 'cardNumber']
            }
          ]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(transactions);
  } catch (error) {
    logger.error(`Ошибка при получении истории операций по рассрочке: ${error.message}`);
    next(error);
  }
};

/**
 * Получение истории операций по карте
 */
exports.getCardTransactions = async (req, res, next) => {
  try {
    const { cardId } = req.params;

    const card = await Card.findOne({
      where: { id: cardId, userId: req.user.id }
    });

    if (!card) {
      throw new ApiError(404, 'Карта не найдена');
    }

    const transactions = await Transaction.findAll({
      where: { userId: req.user.id },
      include: [
        {
          model: Payment,
          where: { cardId },
          attributes: ['id', 'amount', 'paymentDate'],
          required: true
        },
        {
          model: Installment,
          attributes: ['id', 'title', 'status']
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(transactions);
  } catch (error) {
    logger.error(`Ошибка при получении истории операций по карте: ${error.message}`);
    next(error);
  }
};

/**
 * Получение полной истории операций (для администратора)
 */
exports.getAllTransactions = async (req, res, next) => {
  try {
    const transactions = await Transaction.findAll({
      include: [
        {
          model: Installment,
          attributes: ['id', 'title', 'status', 'userId']
        },
        {
          model: Payment,
          attributes: ['id', 'amount', 'paymentDate'],
          include: [
            {
              model: Card,
              attributes: ['id', 'cardNumber', 'userId']
            }
          ]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(transactions);
  } catch (error) {
    logger.error(`Ошибка при получении полной истории операций: ${error.message}`);
    next(error);
  }
};

/**
 * Создание записи в истории операций
 * Внутренняя функция, не экспортируется как API-метод
 */
exports.createTransaction = async (type, userId, details) => {
  try {
    const transaction = await Transaction.create({
      type,
      userId,
      installmentId: details.installmentId,
      paymentId: details.paymentId,
      amount: details.amount,
      details: details
    });
    
    logger.info(`Создана запись в истории операций: ${transaction.id}, тип: ${type}`);
    
    return transaction;
  } catch (error) {
    logger.error(`Ошибка при создании записи в истории: ${error.message}`);
    throw error;
  }
}; 