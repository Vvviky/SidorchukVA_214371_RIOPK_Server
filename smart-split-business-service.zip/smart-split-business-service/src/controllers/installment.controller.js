const { Installment, Payment, PaymentSchedule, InstallmentTemplate } = require('../models');
const calculationService = require('../services/calculationService');
const transactionController = require('./transaction.controller');
const logger = require('../utils/logger');
const { Transaction } = require('../models');
const { ApiError } = require('../utils/errors');
const { Op } = require('sequelize');

/**
 * Получение всех рассрочек пользователя
 */
exports.getUserInstallments = async (req, res, next) => {
  try {
    const { status, search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
    // Получаем ID пользователя из токена
    const userId = req.user?.id;
    const isAdmin = req.user?.role === 'admin';

    // Проверяем наличие ID пользователя
    if (!userId) {
      return res.status(401).json({ 
        message: 'Не удалось определить пользователя', 
        details: 'Требуется авторизация' 
      });
    }

    const where = {};
    // Обычные пользователи видят только свои рассрочки
    if (!isAdmin) {
      where.userId = userId;
    }
    
    if (status) {
      where.status = status;
    }
    if (search) {
      where.title = {
        [Op.iLike]: `%${search}%`
      };
    }

    const order = [[sortBy, sortOrder.toUpperCase()]];

    const installments = await Installment.findAll({
      where,
      order,
      include: [{
        model: Payment,
        as: 'payments',
        attributes: ['id', 'installmentId', 'amount', 'dueDate', 'status', 'paidAt', 'createdAt', 'updatedAt']
      }]
    });

    logger.info(`Получено ${installments.length} рассрочек для пользователя ${userId}${isAdmin ? ' (администратор)' : ''}`);
    
    res.json({ data: installments });
  } catch (err) {
    logger.error(`Ошибка при получении рассрочек: ${err.message}`);
    next(err);
  }
};

/**
 * Получение рассрочки по ID
 */
exports.getInstallmentDetails = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Находим рассрочку без привязки к конкретному пользователю
    const installment = await Installment.findOne({
      where: { id },
      include: [
        {
          model: PaymentSchedule,
          as: 'schedules',
          order: [['paymentNumber', 'ASC']]
        }
      ]
    });
    
    if (!installment) {
      throw new ApiError(404, 'Рассрочка не найдена');
    }
    
    res.json(installment);
  } catch (error) {
    logger.error(`Ошибка при получении рассрочки по ID: ${error.message}`);
    next(error);
  }
};

/**
 * Создание новой рассрочки
 */
exports.createInstallment = async (req, res, next) => {
  try {
    const { title, description, totalAmount, term, templateId, userId } = req.body;
    
    // Проверка наличия userId в запросе
    if (!userId) {
      return res.status(400).json({ 
        message: 'Отсутствует идентификатор пользователя', 
        details: 'Для создания рассрочки необходимо указать ID пользователя' 
      });
    }

    const installment = await Installment.create({
      title,
      description,
      totalAmount,
      term,
      status: 'pending',
      userId: userId,
      templateId
    });

    // Создаем запись в истории операций
    await Transaction.create({
      userId: userId,
      installmentId: installment.id,
      type: 'installment_created',
      amount: totalAmount,
      details: {
        title,
        term
      }
    });

    res.status(201).json({ data: installment });
  } catch (err) {
    logger.error(`Ошибка при создании рассрочки: ${err.message}`);
    next(err);
  }
};

/**
 * Активация рассрочки
 */
exports.activateInstallment = async (req, res, next) => {
  try {
    const { id } = req.params;
    // Используем стандартный идентификатор для логирования
    const userId = req.user?.id || 'system';
    
    const installment = await Installment.findOne({
      where: { id }
    });
    
    if (!installment) {
      return res.status(404).json({ message: 'Рассрочка не найдена' });
    }
    
    if (installment.status !== 'pending' && installment.status !== 'approved') {
      return res.status(400).json({ message: 'Рассрочка уже активирована или завершена' });
    }
    
    // Активация рассрочки
    installment.status = 'active';
    installment.startDate = new Date();
    
    // Рассчитываем endDate (startDate + term месяцев)
    const endDate = new Date(installment.startDate);
    endDate.setMonth(endDate.getMonth() + installment.term);
    installment.endDate = endDate;
    
    await installment.save();
    
    // Обновляем график платежей с фактической датой начала
    const schedules = await PaymentSchedule.findAll({
      where: { installmentId: id },
      order: [['paymentNumber', 'ASC']]
    });
    
    let currentDate = new Date(installment.startDate);
    for (const schedule of schedules) {
      schedule.plannedDate = new Date(currentDate);
      await schedule.save();
      
      // Увеличиваем дату на месяц для следующего платежа
      currentDate.setMonth(currentDate.getMonth() + 1);
    }
    
    // Обновляем информацию о следующем платеже
    if (schedules.length > 0) {
      installment.nextPaymentDate = schedules[0].plannedDate;
      installment.nextPaymentAmount = schedules[0].amount;
      await installment.save();
    }
    
    // Запись в историю операций
    await transactionController.createTransaction('installment_activated', userId, {
      installmentId: installment.id,
      title: installment.title,
      startDate: installment.startDate,
      endDate: installment.endDate
    });
    
    logger.info(`Активирована рассрочка: ${id}, пользователь: ${userId}`);
    
    res.json(installment);
  } catch (error) {
    logger.error(`Ошибка при активации рассрочки: ${error.message}`);
    next(error);
  }
};

/**
 * Отмена рассрочки
 */
exports.cancelInstallment = async (req, res, next) => {
  try {
    const { id } = req.params;
    // Используем стандартный идентификатор для логирования
    const userId = req.user?.id || 'system';
    
    const installment = await Installment.findOne({
      where: { id }
    });
    
    if (!installment) {
      return res.status(404).json({ message: 'Рассрочка не найдена' });
    }
    
    if (installment.status === 'completed') {
      return res.status(400).json({ message: 'Невозможно отменить завершенную рассрочку' });
    }
    
    // Отмена рассрочки
    installment.status = 'cancelled';
    await installment.save();
    
    // Запись в историю операций
    await transactionController.createTransaction('installment_cancelled', userId, {
      installmentId: installment.id,
      title: installment.title,
      previousStatus: installment.status
    });
    
    logger.info(`Отменена рассрочка: ${id}, пользователь: ${userId}`);
    
    res.json(installment);
  } catch (error) {
    logger.error(`Ошибка при отмене рассрочки: ${error.message}`);
    next(error);
  }
};

/**
 * Одобрение рассрочки администратором
 */
exports.approveInstallment = async (req, res, next) => {
  try {
    const { id } = req.params;
    // Используем любой ID пользователя
    const userId = req.user?.id || '1';

    const installment = await Installment.findOne({
      where: { id }
    });

    if (!installment) {
      throw new ApiError(404, 'Рассрочка не найдена');
    }

    // Рассчитываем график платежей
    const monthlyPayment = installment.totalAmount / installment.term;
    const schedules = [];

    for (let i = 1; i <= installment.term; i++) {
      const paymentDate = new Date();
      paymentDate.setMonth(paymentDate.getMonth() + i);

      schedules.push({
        installmentId: installment.id,
        paymentNumber: i,
        plannedDate: paymentDate,
        amount: monthlyPayment
      });
    }

    // Создаем график платежей
    await PaymentSchedule.bulkCreate(schedules);

    // Обновляем статус рассрочки
    await installment.update({
      status: 'active',
      startDate: new Date(),
      nextPaymentDate: schedules[0].plannedDate,
      nextPaymentAmount: monthlyPayment
    });

    // Создаем запись в истории операций
    await Transaction.create({
      userId: userId,
      installmentId: installment.id,
      type: 'installment_activated',
      amount: installment.totalAmount,
      details: {
        term: installment.term,
        monthlyPayment
      }
    });

    res.json(installment);
  } catch (error) {
    logger.error(`Ошибка при одобрении рассрочки: ${error.message}`);
    next(error);
  }
};

/**
 * Отклонение рассрочки администратором
 */
exports.rejectInstallment = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    // Используем любой ID пользователя
    const userId = req.user?.id || '1';

    const installment = await Installment.findOne({
      where: { id }
    });

    if (!installment) {
      throw new ApiError(404, 'Рассрочка не найдена');
    }

    installment.status = 'rejected';
    installment.rejectionReason = reason;
    await installment.save();

    // Запись в историю операций
    await transactionController.createTransaction('installment_rejected', userId, {
      installmentId: installment.id,
      title: installment.title,
      reason
    });

    logger.info(`Отклонена рассрочка: ${id}, администратор: ${userId}`);

    res.json(installment);
  } catch (error) {
    logger.error(`Ошибка при отклонении рассрочки: ${error.message}`);
    next(error);
  }
};

/**
 * Получение списка рассрочек, ожидающих одобрения (для администраторов)
 */
exports.getPendingInstallments = async (req, res, next) => {
  try {
    // Удаляем проверку роли пользователя
    // if (req.user.role !== 'admin') {
    //   return res.status(403).json({ message: 'Недостаточно прав для просмотра ожидающих одобрения рассрочек' });
    // }
    
    const pendingInstallments = await Installment.findAll({
      where: { status: 'pending' },
      order: [['createdAt', 'DESC']],
      include: [
        {
          model: InstallmentTemplate,
          as: 'template',
          attributes: ['name', 'category']
        }
      ]
    });
    
    res.json(pendingInstallments);
  } catch (error) {
    logger.error(`Ошибка при получении ожидающих одобрения рассрочек: ${error.message}`);
    next(error);
  }
};

/**
 * Создание рассрочки из шаблона
 */
exports.createFromTemplate = async (req, res, next) => {
  try {
    const { templateId } = req.params;
    const { userId } = req.body;
    
    logger.info(`Попытка создания рассрочки из шаблона: templateId=${templateId}, userId=${userId}`);
    
    // Проверка наличия userId в запросе
    if (!userId) {
      logger.error('Отсутствует идентификатор пользователя в запросе');
      return res.status(400).json({ 
        message: 'Отсутствует идентификатор пользователя', 
        details: 'Для создания рассрочки из шаблона необходимо указать ID пользователя' 
      });
    }

    const template = await InstallmentTemplate.findOne({
      where: { id: templateId }
    });

    if (!template) {
      logger.error(`Шаблон с ID=${templateId} не найден`);
      throw new ApiError(404, 'Шаблон не найден');
    }
    
    logger.info(`Шаблон найден: ${template.name}, создаем рассрочку`);

    const installment = await Installment.create({
      title: template.name || 'Рассрочка из шаблона',
      description: template.description || '',
      totalAmount: template.defaultAmount || 5000,
      term: template.defaultTerm || 6,
      status: 'pending',
      userId: userId,
      templateId
    });
    
    logger.info(`Рассрочка создана: ID=${installment.id}`);

    try {
      // Создаем запись в истории операций
      await Transaction.create({
        userId: userId,
        installmentId: installment.id,
        type: 'installment_created',  // Используем существующий тип
        amount: installment.totalAmount,
        details: {
          templateId,
          title: installment.title,
          term: installment.term,
          fromTemplate: true  // Добавляем флаг, что создано из шаблона
        }
      });
      
      logger.info(`Транзакция создана для рассрочки из шаблона: installmentId=${installment.id}`);
    } catch (transactionError) {
      // Если возникла ошибка при создании транзакции, логируем ее,
      // но продолжаем выполнение - рассрочка уже создана
      logger.error(`Ошибка при создании транзакции: ${transactionError.message}`);
      logger.error(transactionError.stack);
    }

    res.status(201).json({ data: installment });
  } catch (err) {
    logger.error(`Ошибка при создании рассрочки из шаблона: ${err.message}`);
    logger.error(err.stack);
    next(err);
  }
};

/**
 * Получение всех рассрочек (для администратора)
 */
exports.getAllInstallments = async (req, res, next) => {
  try {
    const { status, search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

    const where = {};
    if (status) {
      where.status = status;
    }
    if (search) {
      where.title = {
        [Op.iLike]: `%${search}%`
      };
    }

    const order = [[sortBy, sortOrder.toUpperCase()]];

    const installments = await Installment.findAll({
      where,
      order,
      include: [{
        model: Payment,
        as: 'payments'
      }]
    });

    res.json({ data: installments });
  } catch (err) {
    logger.error(`Ошибка при получении всех рассрочек: ${err.message}`);
    next(err);
  }
};

/**
 * Получение платежей по рассрочке
 */
exports.getPayments = async (req, res, next) => {
  try {
    const { id } = req.params;
    console.log(`Запрос на получение платежей для рассрочки с ID ${id}`);

    const installment = await Installment.findByPk(id);
    if (!installment) {
      console.log(`Рассрочка с ID ${id} не найдена`);
      return res.status(404).json({ 
        message: 'Рассрочка не найдена',
        data: [] 
      });
    }

    const payments = await Payment.findAll({
      where: { installmentId: id },
      order: [['createdAt', 'DESC']]  // Сортировка по дате создания (сначала новые)
    });

    console.log(`Найдено ${payments.length} платежей для рассрочки с ID ${id}`);

    // Добавляем данные о платежах в ответ
    return res.json({ 
      data: payments, 
      installment: {
        id: installment.id,
        totalAmount: installment.totalAmount,
        paidAmount: installment.paidAmount || 0,
        remainingAmount: installment.totalAmount - (installment.paidAmount || 0)
      } 
    });
  } catch (err) {
    console.error(`Ошибка при получении платежей: ${err.message}`);
    next(err);
  }
};

module.exports = {
  getUserInstallments: exports.getUserInstallments,
  getInstallmentDetails: exports.getInstallmentDetails,
  createInstallment: exports.createInstallment,
  activateInstallment: exports.activateInstallment,
  cancelInstallment: exports.cancelInstallment,
  approveInstallment: exports.approveInstallment,
  rejectInstallment: exports.rejectInstallment,
  getPendingInstallments: exports.getPendingInstallments,
  createFromTemplate: exports.createFromTemplate,
  getAllInstallments: exports.getAllInstallments,
  getPayments: exports.getPayments
}; 