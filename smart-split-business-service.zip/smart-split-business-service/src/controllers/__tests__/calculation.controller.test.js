const calculationController = require('../calculation.controller');
const calculationService = require('../../services/calculation.service');
const ApiError = require('../../utils/ApiError');

jest.mock('../../services/calculation.service');

describe('CalculationController', () => {
  let req, res, next;

  beforeEach(() => {
    req = {
      body: {},
      user: { id: 1 }
    };
    res = {
      json: jest.fn(),
      status: jest.fn().mockReturnThis()
    };
    next = jest.fn();
  });

  describe('calculateMonthlyPayment', () => {
    it('should calculate monthly payment and return result', async () => {
      const mockResult = 8791.59;
      calculationService.calculateMonthlyPayment.mockReturnValue(mockResult);
      
      req.body = {
        amount: 100000,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculateMonthlyPayment(req, res, next);

      expect(calculationService.calculateMonthlyPayment).toHaveBeenCalledWith(100000, 12, 10);
      expect(res.json).toHaveBeenCalledWith({
        monthlyPayment: mockResult,
        totalAmount: mockResult * 12,
        overpayment: mockResult * 12 - 100000
      });
    });

    it('should handle validation errors', async () => {
      req.body = {
        amount: 0,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculateMonthlyPayment(req, res, next);

      expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    });
  });

  describe('calculatePaymentSchedule', () => {
    it('should calculate payment schedule and return result', async () => {
      const mockSchedule = [
        {
          paymentNumber: 1,
          paymentDate: new Date(),
          paymentAmount: 8791.59,
          principalAmount: 7958.26,
          interestAmount: 833.33,
          remainingBalance: 92041.74
        }
      ];
      const mockResult = {
        schedule: mockSchedule,
        totalAmount: 105499.08,
        overpayment: 5499.08
      };
      
      calculationService.calculatePaymentSchedule.mockReturnValue(mockResult);
      
      req.body = {
        amount: 100000,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculatePaymentSchedule(req, res, next);

      expect(calculationService.calculatePaymentSchedule).toHaveBeenCalledWith(100000, 12, 10);
      expect(res.json).toHaveBeenCalledWith(mockResult);
    });

    it('should handle validation errors', async () => {
      req.body = {
        amount: 0,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculatePaymentSchedule(req, res, next);

      expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    });
  });

  describe('calculateMaxAmount', () => {
    it('should calculate max amount and return result', async () => {
      const mockResult = {
        maxAmount: 300000,
        monthlyPayment: 25000,
        totalAmount: 300000,
        overpayment: 30000
      };
      
      calculationService.calculateMaxAmount.mockReturnValue(mockResult);
      
      req.body = {
        monthlyIncome: 50000,
        monthlyExpenses: 20000,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculateMaxAmount(req, res, next);

      expect(calculationService.calculateMaxAmount).toHaveBeenCalledWith(50000, 20000, 12, 10);
      expect(res.json).toHaveBeenCalledWith(mockResult);
    });

    it('should handle validation errors', async () => {
      req.body = {
        monthlyIncome: 0,
        monthlyExpenses: 20000,
        term: 12,
        interestRate: 10
      };

      await calculationController.calculateMaxAmount(req, res, next);

      expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    });
  });
}); 