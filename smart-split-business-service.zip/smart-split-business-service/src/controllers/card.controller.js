const { Card } = require('../models');
const { ApiError } = require('../utils/errors');

// Получение списка карт пользователя
const getUserCards = async (req, res, next) => {
  try {
    const cards = await Card.findAll({
      where: { userId: req.user.id },
      order: [['isDefault', 'DESC'], ['createdAt', 'DESC']]
    });
    res.json(cards);
  } catch (error) {
    next(error);
  }
};

// Создание новой карты
const createCard = async (req, res, next) => {
  try {
    const { cardNumber, cardHolder, expiryDate, cvv } = req.body;

    // Проверяем, не существует ли уже карта с таким номером
    const existingCard = await Card.findOne({ where: { cardNumber } });
    if (existingCard) {
      throw new ApiError(400, 'Карта с таким номером уже существует');
    }

    const card = await Card.create({
      userId: req.user.id,
      cardNumber,
      cardHolder,
      expiryDate,
      cvv
    });

    res.status(201).json(card);
  } catch (error) {
    next(error);
  }
};

// Удаление карты
const deleteCard = async (req, res, next) => {
  try {
    const { id } = req.params;

    const card = await Card.findOne({
      where: { id, userId: req.user.id }
    });

    if (!card) {
      throw new ApiError(404, 'Карта не найдена');
    }

    await card.destroy();
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

// Установка карты по умолчанию
const setDefaultCard = async (req, res, next) => {
  try {
    const { id } = req.params;

    const card = await Card.findOne({
      where: { id, userId: req.user.id }
    });

    if (!card) {
      throw new ApiError(404, 'Карта не найдена');
    }

    // Снимаем флаг isDefault со всех карт пользователя
    await Card.update(
      { isDefault: false },
      { where: { userId: req.user.id } }
    );

    // Устанавливаем флаг isDefault для выбранной карты
    await card.update({ isDefault: true });

    res.json(card);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getUserCards,
  createCard,
  deleteCard,
  setDefaultCard
}; 