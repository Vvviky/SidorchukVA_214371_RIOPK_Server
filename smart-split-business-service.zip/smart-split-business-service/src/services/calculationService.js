const { ApiError } = require('../utils/ApiError');

/**
 * Расчет ежемесячного платежа по аннуитетной схеме
 * @param {number} amount - Сумма кредита
 * @param {number} term - Срок в месяцах
 * @param {number} interestRate - Годовая процентная ставка
 * @returns {number} - Ежемесячный платеж
 */
const calculateMonthlyPayment = (amount, term, interestRate) => {
  if (amount <= 0 || term <= 0 || interestRate < 0) {
    throw ApiError.badRequest('Некорректные параметры для расчета платежа');
  }

  const monthlyRate = interestRate / 12 / 100;
  const numerator = amount * monthlyRate * Math.pow(1 + monthlyRate, term);
  const denominator = Math.pow(1 + monthlyRate, term) - 1;

  return Math.round(numerator / denominator * 100) / 100;
};

/**
 * Расчет графика платежей
 * @param {number} amount - Сумма кредита
 * @param {number} term - Срок в месяцах
 * @param {number} interestRate - Годовая процентная ставка
 * @returns {Array} - Массив объектов с информацией о платежах
 */
const calculatePaymentSchedule = (amount, term, interestRate) => {
  const monthlyPayment = calculateMonthlyPayment(amount, term, interestRate);
  const schedule = [];
  let remainingAmount = amount;
  const monthlyRate = interestRate / 12 / 100;

  for (let i = 1; i <= term; i++) {
    const interestPayment = Math.round(remainingAmount * monthlyRate * 100) / 100;
    const principalPayment = Math.round((monthlyPayment - interestPayment) * 100) / 100;
    
    remainingAmount = Math.round((remainingAmount - principalPayment) * 100) / 100;

    schedule.push({
      paymentNumber: i,
      plannedDate: new Date(new Date().setMonth(new Date().getMonth() + i)),
      amount: monthlyPayment,
      principalPayment,
      interestPayment,
      remainingAmount
    });
  }

  return schedule;
};

/**
 * Расчет переплаты по кредиту
 * @param {number} amount - Сумма кредита
 * @param {number} term - Срок в месяцах
 * @param {number} interestRate - Годовая процентная ставка
 * @returns {number} - Сумма переплаты
 */
const calculateOverpayment = (amount, term, interestRate) => {
  const monthlyPayment = calculateMonthlyPayment(amount, term, interestRate);
  return Math.round((monthlyPayment * term - amount) * 100) / 100;
};

module.exports = {
  calculateMonthlyPayment,
  calculatePaymentSchedule,
  calculateOverpayment
}; 