const { Payment } = require('../models');
const ApiError = require('../utils/ApiError');
const { Op } = require('sequelize');

class PaymentService {
  async createPayment(installmentId, amount, dueDate) {
    try {
      const payment = await Payment.create({
        installmentId,
        amount,
        dueDate
      });
      return payment;
    } catch (error) {
      throw new ApiError(500, 'Ошибка при создании платежа');
    }
  }

  async getPaymentsByInstallmentId(installmentId) {
    try {
      const payments = await Payment.findAll({ 
        where: { installmentId },
        order: [['dueDate', 'ASC']] 
      });
      return payments;
    } catch (error) {
      throw new ApiError(500, 'Ошибка при получении платежей');
    }
  }

  async updatePaymentStatus(paymentId, status) {
    try {
      const payment = await Payment.findByPk(paymentId);
      if (!payment) {
        throw new ApiError(404, 'Платеж не найден');
      }

      payment.status = status;
      if (status === 'paid') {
        payment.paidAt = new Date();
      }
      await payment.save();
      return payment;
    } catch (error) {
      if (error instanceof ApiError) {
        throw error;
      }
      throw new ApiError(500, 'Ошибка при обновлении статуса платежа');
    }
  }

  async getOverduePayments() {
    try {
      const now = new Date();
      const payments = await Payment.findAll({
        where: {
          status: 'pending',
          dueDate: { [Op.lt]: now }
        }
      });
      return payments;
    } catch (error) {
      throw new ApiError(500, 'Ошибка при получении просроченных платежей');
    }
  }
}

module.exports = new PaymentService(); 