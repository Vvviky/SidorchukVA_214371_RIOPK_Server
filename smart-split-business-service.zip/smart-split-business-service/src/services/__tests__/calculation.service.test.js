const calculationService = require('../calculation.service');
const ApiError = require('../../utils/ApiError');

describe('CalculationService', () => {
  describe('calculateMonthlyPayment', () => {
    it('should calculate correct monthly payment', () => {
      const result = calculationService.calculateMonthlyPayment(100000, 12, 10);
      expect(result).toBeCloseTo(8791.59, 2);
    });

    it('should throw error for invalid parameters', () => {
      expect(() => calculationService.calculateMonthlyPayment(0, 12, 10)).toThrow(ApiError);
      expect(() => calculationService.calculateMonthlyPayment(100000, 0, 10)).toThrow(ApiError);
      expect(() => calculationService.calculateMonthlyPayment(100000, 12, -1)).toThrow(ApiError);
    });
  });

  describe('calculatePaymentSchedule', () => {
    it('should calculate correct payment schedule', () => {
      const result = calculationService.calculatePaymentSchedule(100000, 12, 10);
      
      expect(result.schedule).toHaveLength(12);
      expect(result.totalAmount).toBeCloseTo(105499.08, 2);
      expect(result.overpayment).toBeCloseTo(5499.08, 2);

      const firstPayment = result.schedule[0];
      expect(firstPayment.paymentNumber).toBe(1);
      expect(firstPayment.paymentAmount).toBeCloseTo(8791.59, 2);
      expect(firstPayment.principalAmount).toBeCloseTo(7958.26, 2);
      expect(firstPayment.interestAmount).toBeCloseTo(833.33, 2);
      expect(firstPayment.remainingBalance).toBeCloseTo(92041.74, 2);
    });

    it('should throw error for invalid parameters', () => {
      expect(() => calculationService.calculatePaymentSchedule(0, 12, 10)).toThrow(ApiError);
      expect(() => calculationService.calculatePaymentSchedule(100000, 0, 10)).toThrow(ApiError);
      expect(() => calculationService.calculatePaymentSchedule(100000, 12, -1)).toThrow(ApiError);
    });
  });

  describe('calculateMaxAmount', () => {
    it('should calculate correct max amount', () => {
      const result = calculationService.calculateMaxAmount(50000, 20000, 12, 10);
      
      expect(result.maxAmount).toBeGreaterThan(0);
      expect(result.monthlyPayment).toBeLessThanOrEqual(30000); // 60% от дохода
      expect(result.totalAmount).toBeGreaterThan(result.maxAmount);
      expect(result.overpayment).toBeGreaterThan(0);
    });

    it('should throw error for invalid parameters', () => {
      expect(() => calculationService.calculateMaxAmount(0, 20000, 12, 10)).toThrow(ApiError);
      expect(() => calculationService.calculateMaxAmount(50000, -1, 12, 10)).toThrow(ApiError);
      expect(() => calculationService.calculateMaxAmount(50000, 20000, 0, 10)).toThrow(ApiError);
      expect(() => calculationService.calculateMaxAmount(50000, 20000, 12, -1)).toThrow(ApiError);
    });
  });
}); 