require('dotenv').config();

const config = {
  // Настройки сервера
  server: {
    port: process.env.PORT || 5001,
  },

  // Настройки базы данных
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    name: process.env.DB_NAME || 'smart_split_business',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '12345',
  },

  // Настройки JWT
  jwt: {
    secret: process.env.JWT_SECRET || 'your-secret-key',
    expiresIn: '24h',
  },

  // Настройки CORS
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    credentials: true,
  },

  // Настройки внешних сервисов
  services: {
    auth: {
      url: process.env.AUTH_SERVICE_URL || 'http://localhost:5000/api/auth',
    },
  },

  // Настройки логирования
  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },
};

module.exports = config; 