const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const errorHandler = require('./middleware/error.middleware');
const installmentRoutes = require('./routes/installment.routes');
const paymentRoutes = require('./routes/payment.routes');
const calculationRoutes = require('./routes/calculation.routes');
const transactionRoutes = require('./routes/transaction.routes');
const config = require('./config');
const routes = require('./routes');
const logger = require('./utils/logger');
const { initializeDatabase } = require('./utils/dbInit');

const app = express();

// Настройка ограничения запросов
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 минут
  max: 100, // ограничение 100 запросов на IP
  standardHeaders: true,
  legacyHeaders: false
});

// Основные промежуточные слои
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// app.use(morgan('dev'));
app.use(limiter);

// Регистрация маршрутов
app.use('/api/installments', installmentRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/calculations', calculationRoutes);
app.use('/api/transactions', transactionRoutes);

// Маршрут для проверки работоспособности сервиса
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', service: 'smart-split-business-service' });
});

// Обработка ошибок
app.use(errorHandler);

module.exports = app; 