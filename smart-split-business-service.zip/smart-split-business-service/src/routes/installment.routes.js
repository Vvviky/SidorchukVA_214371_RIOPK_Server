const express = require('express');
const router = express.Router();
const installmentController = require('../controllers/installment.controller');
// Восстанавливаем middleware для аутентификации и авторизации
const authMiddleware = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/auth.middleware');
const { 
  validateCreateInstallment, 
  validateInstallmentId,
  validate 
} = require('../middleware/validation.middleware');

// Восстанавливаем проверку аутентификации для всех маршрутов
router.use(authMiddleware);

// Маршруты для пользователей (возвращаем проверки)
router.post('/', validateCreateInstallment, installmentController.createInstallment);
router.get('/user', installmentController.getUserInstallments);
router.get('/user/:id', validateInstallmentId, installmentController.getInstallmentDetails);

// Маршруты для администраторов (возвращаем проверку на роль админа)
router.get('/admin', authorize(['admin']), installmentController.getAllInstallments);
router.patch('/admin/:id/approve', authorize(['admin']), validateInstallmentId, installmentController.approveInstallment);
router.patch('/admin/:id/reject', authorize(['admin']), validateInstallmentId, installmentController.rejectInstallment);

/**
 * @route GET /api/installments
 * @desc Получение всех рассрочек пользователя или всех рассрочек для администратора
 * @access Private
 */
router.get('/', installmentController.getUserInstallments);

/**
 * @route GET /api/installments/:id
 * @desc Получение рассрочки по ID
 * @access Private
 */
router.get('/:id', validateInstallmentId, installmentController.getInstallmentDetails);

/**
 * @route PATCH /api/installments/:id/activate
 * @desc Активация рассрочки
 * @access Private
 */
router.patch('/:id/activate', validateInstallmentId, installmentController.activateInstallment);

/**
 * @route PATCH /api/installments/:id/cancel
 * @desc Отмена рассрочки
 * @access Private
 */
router.patch('/:id/cancel', validateInstallmentId, installmentController.cancelInstallment);

/**
 * @route GET /api/installments/admin/pending
 * @desc Получение всех рассрочек, ожидающих одобрения
 * @access Admin
 */
router.get('/admin/pending', authorize(['admin']), installmentController.getPendingInstallments);

/**
 * @route POST /api/installments/template/:templateId
 * @desc Создание рассрочки на основе шаблона
 * @access Private
 */
router.post('/template/:templateId', installmentController.createFromTemplate);

/**
 * @route GET /api/installments/:id/payments
 * @desc Получение платежей по рассрочке
 * @access Private
 */
router.get('/:id/payments', validateInstallmentId, installmentController.getPayments);

module.exports = router; 