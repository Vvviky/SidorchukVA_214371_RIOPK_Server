const express = require('express');
const router = express.Router();
const calculationController = require('../controllers/calculation.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Все маршруты требуют аутентификации
router.use(authMiddleware);

// Расчет ежемесячного платежа
router.post('/monthly-payment', calculationController.calculateMonthlyPayment);

// Расчет графика платежей
router.post('/payment-schedule', calculationController.calculatePaymentSchedule);

// Расчет максимальной суммы кредита
router.post('/max-amount', calculationController.calculateMaxAmount);

module.exports = router; 