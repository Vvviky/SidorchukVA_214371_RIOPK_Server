const express = require('express');
const router = express.Router();
const cardController = require('../controllers/card.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Все маршруты требуют аутентификации
router.use(authMiddleware);

// Получение списка карт пользователя
router.get('/', cardController.getUserCards);

// Создание новой карты
router.post('/', cardController.createCard);

// Удаление карты
router.delete('/:id', cardController.deleteCard);

// Установка карты по умолчанию
router.patch('/:id/default', cardController.setDefaultCard);

module.exports = router; 