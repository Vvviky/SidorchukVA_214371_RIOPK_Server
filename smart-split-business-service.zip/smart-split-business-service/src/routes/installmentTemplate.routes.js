const express = require('express');
const router = express.Router();
const installmentTemplateController = require('../controllers/installmentTemplate.controller');
const authMiddleware = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/auth.middleware');
const { validateCreateTemplate, validateUpdateTemplate } = require('../middleware/validation.middleware');

// Все маршруты требуют аутентификации
router.use(authMiddleware);

// Маршруты для пользователей
router.get('/active', installmentTemplateController.getActiveTemplates);
router.get('/:id', installmentTemplateController.getTemplateById);

// Маршруты для администраторов
router.get('/', authorize(['admin']), installmentTemplateController.getAllTemplates);
router.post('/', authorize(['admin']), validateCreateTemplate, installmentTemplateController.createTemplate);
router.put('/:id', authorize(['admin']), validateUpdateTemplate, installmentTemplateController.updateTemplate);
router.delete('/:id', authorize(['admin']), installmentTemplateController.deleteTemplate);
router.patch('/:id/toggle', authorize(['admin']), installmentTemplateController.toggleTemplateStatus);

module.exports = router; 