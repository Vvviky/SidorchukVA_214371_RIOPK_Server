const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/payment.controller');
const authMiddleware = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/auth.middleware');
const { 
  validateCreatePayment,
  validateInstallmentId,
  validatePaymentId
} = require('../middleware/validation.middleware');

// Все маршруты требуют аутентификации
router.use(authMiddleware);

/**
 * @route GET /api/payments
 * @desc Получение всех платежей пользователя
 * @access Private
 */
router.get('/', paymentController.getUserPayments);

/**
 * @route GET /api/payments/admin
 * @desc Получение всех платежей (для администратора)
 * @access Admin
 */
router.get('/admin', authorize(['admin']), paymentController.getAllPayments);

/**
 * @route GET /api/payments/overdue
 * @desc Получение просроченных платежей (только для администраторов)
 * @access Admin
 */
router.get('/overdue', authorize(['admin']), paymentController.getOverduePayments);

/**
 * @route POST /api/payments/simulate
 * @desc Имитация платежа по рассрочке (специально для тестирования)
 * @access Private
 */
router.post('/simulate', paymentController.createPayment);

/**
 * @route GET /api/payments/installment/:installmentId
 * @desc Получение платежей по ID рассрочки
 * @access Private
 */
router.get('/installment/:installmentId', validateInstallmentId, paymentController.getPaymentsByInstallmentId);

/**
 * @route POST /api/payments/:installmentId
 * @desc Создание нового платежа
 * @access Private
 */
router.post('/:installmentId', validateInstallmentId, validateCreatePayment, paymentController.createPayment);

/**
 * @route PATCH /api/payments/:paymentId/status
 * @desc Обновление статуса платежа (только для администраторов)
 * @access Admin
 */
router.patch('/:paymentId/status', authorize(['admin']), paymentController.updatePaymentStatus);

/**
 * @route GET /api/payments/:installmentId/schedule
 * @desc Получение графика платежей по рассрочке
 * @access Private
 */
router.get('/:installmentId/schedule', validateInstallmentId, paymentController.getPaymentSchedule);

/**
 * @route GET /api/payments/:id
 * @desc Получение деталей платежа
 * @access Private
 */
router.get('/:id', validatePaymentId, paymentController.getPaymentDetails);

module.exports = router; 