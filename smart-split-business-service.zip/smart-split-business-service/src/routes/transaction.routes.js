const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transaction.controller');
const authMiddleware = require('../middleware/auth.middleware');
const adminMiddleware = require('../middleware/admin.middleware');

// Все маршруты требуют аутентификации
router.use(authMiddleware);

// Маршруты для пользователей
router.get('/user', transactionController.getUserTransactions);
router.get('/user/installment/:installmentId', transactionController.getInstallmentTransactions);
router.get('/user/card/:cardId', transactionController.getCardTransactions);

// Маршруты для администраторов
router.get('/admin', adminMiddleware, transactionController.getAllTransactions);

module.exports = router; 