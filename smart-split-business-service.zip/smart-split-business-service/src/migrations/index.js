const { sequelize } = require('../models');
const path = require('path');
const fs = require('fs');

const runMigrations = async () => {
  try {
    // Получаем список файлов миграций и сортируем их
    const migrationFiles = fs.readdirSync(__dirname)
      .filter(file => file.endsWith('.js') && file !== 'index.js')
      .sort((a, b) => {
        // Особый порядок для файлов с шаблонами - они должны быть выполнены первыми
        if (a.includes('template') && !b.includes('template')) return -1;
        if (!a.includes('template') && b.includes('template')) return 1;
        return a.localeCompare(b);
      });

    console.log('Порядок выполнения миграций:');
    migrationFiles.forEach(file => console.log(`- ${file}`));

    // Запускаем каждую миграцию
    for (const file of migrationFiles) {
      try {
        const migration = require(path.join(__dirname, file));
        await migration.up(sequelize.getQueryInterface(), sequelize.constructor);
        console.log(`Миграция ${file} успешно выполнена`);
      } catch (error) {
        console.error(`Ошибка при выполнении миграции ${file}:`, error.message);
        throw error;
      }
    }

    console.log('Все миграции успешно выполнены');
  } catch (error) {
    console.error('Ошибка при выполнении миграций:', error);
    process.exit(1);
  }
};

runMigrations(); 