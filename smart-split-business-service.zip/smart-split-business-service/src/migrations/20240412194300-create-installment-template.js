'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('InstallmentTemplates', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      description: {
        type: Sequelize.TEXT
      },
      minAmount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      maxAmount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      minTerm: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      maxTerm: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      interestRate: {
        type: Sequelize.DECIMAL(5, 2),
        allowNull: false
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('InstallmentTemplates');
  }
}; 