'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Сначала удалим все существующие данные и индексы
    await queryInterface.dropTable('Transactions');

    // Создадим таблицу заново с правильными типами
    await queryInterface.createTable('Transactions', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      userId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      installmentId: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      paymentId: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      type: {
        type: Sequelize.ENUM(
          'installment_created',
          'installment_activated',
          'installment_cancelled',
          'installment_completed',
          'installment_rejected',
          'payment_created',
          'schedule_updated',
          'card_created',
          'card_deleted',
          'card_updated',
          'installment_created_from_template'
        ),
        allowNull: false
      },
      details: {
        type: Sequelize.JSONB,
        allowNull: true
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW
      }
    });

    // Создаем индексы
    await queryInterface.addIndex('Transactions', ['userId']);
    await queryInterface.addIndex('Transactions', ['installmentId']);
    await queryInterface.addIndex('Transactions', ['paymentId']);
    await queryInterface.addIndex('Transactions', ['type']);
    await queryInterface.addIndex('Transactions', ['createdAt']);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Transactions');
    
    await queryInterface.createTable('Transactions', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      userId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      installmentId: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      paymentId: {
        type: Sequelize.UUID,
        allowNull: true
      },
      type: {
        type: Sequelize.ENUM(
          'installment_created',
          'installment_activated',
          'installment_cancelled',
          'installment_completed',
          'installment_rejected',
          'payment_created',
          'schedule_updated',
          'card_created',
          'card_deleted',
          'card_updated',
          'installment_created_from_template'
        ),
        allowNull: false
      },
      details: {
        type: Sequelize.JSONB,
        allowNull: true
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW
      }
    });

    await queryInterface.addIndex('Transactions', ['userId']);
    await queryInterface.addIndex('Transactions', ['installmentId']);
    await queryInterface.addIndex('Transactions', ['paymentId']);
    await queryInterface.addIndex('Transactions', ['type']);
    await queryInterface.addIndex('Transactions', ['createdAt']);
  }
}; 