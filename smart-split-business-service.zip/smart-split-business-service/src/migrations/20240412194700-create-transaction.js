'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Transactions', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      type: {
        type: Sequelize.STRING,
        allowNull: false
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      details: {
        type: Sequelize.JSONB
      },
      userId: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      installmentId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Installments',
          key: 'id'
        }
      },
      paymentId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Payments',
          key: 'id'
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Transactions');
  }
}; 