'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('PaymentSchedules', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      paymentNumber: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      plannedDate: {
        type: Sequelize.DATE,
        allowNull: false
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      principalPayment: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      interestPayment: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      remainingAmount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      status: {
        type: Sequelize.ENUM('pending', 'paid', 'overdue'),
        defaultValue: 'pending'
      },
      installmentId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Installments',
          key: 'id'
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('PaymentSchedules');
  }
}; 