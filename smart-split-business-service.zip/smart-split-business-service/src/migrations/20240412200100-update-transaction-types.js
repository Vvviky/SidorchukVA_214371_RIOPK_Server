'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('Transactions', 'userId', {
      type: Sequelize.STRING,
      allowNull: false
    });
    
    await queryInterface.changeColumn('Transactions', 'installmentId', {
      type: Sequelize.INTEGER,
      allowNull: true
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('Transactions', 'userId', {
      type: Sequelize.UUID,
      allowNull: false
    });
    
    await queryInterface.changeColumn('Transactions', 'installmentId', {
      type: Sequelize.UUID,
      allowNull: true
    });
  }
}; 